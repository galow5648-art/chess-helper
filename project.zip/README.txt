Шахматный помощник (Android, Java, без внешних библиотек)

Структура:
  app/src/main/java/com/chesshelper/
    BoardReader.java    - находит доску на кадре и читает фигуры (шаблоны силуэтов, Templates.java)
    GameState.java      - ориентация, чей ход, рокировка, взятие на проходе -> FEN
    StockfishEngine.java- обёртка над UCI-процессом Stockfish
    AssistService.java  - захват экрана, оверлей, главный цикл
    ArrowView.java      - рисует стрелки
    MainActivity.java   - экран запуска и запрос разрешений
  Stockfish кладётся в app/src/main/jniLibs/arm64-v8a/libstockfish.so (это делает build.yml).

Сборка локально: положить libstockfish.so (arm64) в указанную папку и выполнить `gradle assembleDebug`.
