package com.chesshelper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.Locale;

/**
 * Основной сервис: захватывает экран, читает доску, спрашивает Stockfish и рисует стрелки.
 * Потоки: main (вью), bg (захват и распознавание), поток движка.
 */
public class AssistService extends Service {

    public static final String ACTION_STOP = "com.chesshelper.STOP";
    private static final String CHANNEL = "assist";
    private static final int ANALYSIS_MS = 1500;

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread bgThread;
    private Handler bg;

    private WindowManager wm;
    private ArrowView arrowView;
    private LinearLayout panel;
    private TextView statusTv;
    private WindowManager.LayoutParams panelLp;

    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private ImageReader reader;
    private VirtualDisplay display;
    private Image held;            // только поток bg
    private int[] pxBuf;           // только поток bg

    private StockfishEngine engine;
    private final GameState state = new GameState();

    private volatile boolean running;
    private volatile boolean started;
    private volatile boolean dirty = true;
    private volatile boolean analyzing;
    private volatile boolean arrowShown;
    private volatile long ignoreUntil;
    private volatile String committedFen;
    private volatile String pendingFen;
    private volatile GameState.Position committedPos;
    private long lastAnalysis;

    private int screenW, screenH;
    private float panelTopShown = -1;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ============================================================ запуск

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        started = true;

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Помощник", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, AssistService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Шахматный помощник работает")
                .setContentText("Нажми, чтобы остановить")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);

        try {
            int code = intent == null ? 0 : intent.getIntExtra("code", 0);
            Intent data = intent == null ? null : (Intent) intent.getParcelableExtra("data");
            if (data == null) throw new IllegalStateException("нет данных разрешения на запись экрана");

            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;

            bgThread = new HandlerThread("capture");
            bgThread.start();
            bg = new Handler(bgThread.getLooper());

            setupOverlay();

            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            projectionCallback = new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopSelf();
                }
            };
            projection.registerCallback(projectionCallback, main);

            reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    onFrame(r);
                }
            }, bg);
            display = projection.createVirtualDisplay("chess-helper", screenW, screenH, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);

            setupEngine();

            running = true;
            lastAnalysis = SystemClock.elapsedRealtime();
            bg.post(tick);
        } catch (Throwable t) {
            Toast.makeText(this, "Не удалось запустить: " + t, Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void setupEngine() {
        File sf = new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so");
        if (!sf.exists()) {
            setStatus("Stockfish не найден в приложении");
            return;
        }
        int threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() / 2));
        engine = new StockfishEngine(sf.getAbsolutePath(), threads, 64);
        engine.start();
    }

    // ============================================================ оверлей

    private void setupOverlay() {
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        arrowView = new ArrowView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(arrowView, lp);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setPadding(dp(10), dp(6), dp(4), dp(6));
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(0xE6202020);
        bgd.setCornerRadius(dp(10));
        panel.setBackground(bgd);

        statusTv = new TextView(this);
        statusTv.setTextSize(13);
        statusTv.setTextColor(0xFFFFFFFF);
        statusTv.setMaxLines(3);
        statusTv.setText("Открой партию в Chess.com");
        panel.addView(statusTv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        panel.addView(makeButton("⇅", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                state.flip();
                committedFen = null;
                pendingFen = null;
                dirty = true;
                clearArrows();
                setStatus("Перевернул ориентацию, читаю…");
            }
        }));
        panel.addView(makeButton("✕", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        }));

        panelLp = new WindowManager.LayoutParams(
                (int) (screenW * 0.72f),
                dp(70),
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.END;
        panelLp.x = dp(8);
        panelLp.y = (int) (screenH * 0.2f);
        panelLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(panel, panelLp);
    }

    private TextView makeButton(String text, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(20);
        b.setTextColor(0xFFB0BEC5);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10), dp(4), dp(10), dp(4));
        b.setOnClickListener(l);
        return b;
    }

    /** Ставит панель над доской (или под ней, если сверху нет места). Вызывать в main. */
    private void positionPanel(GameState.Position p) {
        if (panel == null) return;
        float boardBottom = p.top + 8 * p.cell;
        float y;
        if (p.top > dp(70) + dp(14)) y = p.top - dp(70) - dp(6);
        else y = boardBottom + dp(6);
        if (Math.abs(y - panelTopShown) < 2f) return;
        panelTopShown = y;
        panelLp.y = (int) y;
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Throwable ignored) {
            // окно уже снято
        }
    }

    private void setStatus(final String text) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (statusTv != null) statusTv.setText(text);
            }
        });
    }

    private void clearArrows() {
        arrowShown = false;
        main.post(new Runnable() {
            @Override
            public void run() {
                if (arrowView != null) {
                    arrowView.clear();
                    arrowView.setAlpha(1f);
                }
            }
        });
    }

    private void setArrowAlpha(final float a) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (arrowView != null) arrowView.setAlpha(a);
            }
        });
    }

    // ============================================================ захват

    private void onFrame(ImageReader r) {
        Image img;
        try {
            img = r.acquireLatestImage();
        } catch (Throwable t) {
            return;
        }
        if (img == null) return;
        if (held != null) {
            try {
                held.close();
            } catch (Throwable ignored) {
                // уже закрыт
            }
        }
        held = img;
        if (SystemClock.elapsedRealtime() >= ignoreUntil) dirty = true;   // настоящее изменение на экране
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long now = SystemClock.elapsedRealtime();
            // страховка: изредка перечитываем экран, даже если кадров не было
            if (now - lastAnalysis > (arrowShown ? 8000 : 3000)) dirty = true;
            if (dirty && !analyzing) {
                dirty = false;
                analyzing = true;
                lastAnalysis = now;
                beginAnalysis();
            }
            bg.postDelayed(this, 350);
        }
    };

    private void beginAnalysis() {
        if (arrowShown) {
            // прячем стрелку на мгновение, чтобы она не попала в кадр
            ignoreUntil = SystemClock.elapsedRealtime() + 800;
            setArrowAlpha(0f);
            bg.postDelayed(new Runnable() {
                @Override
                public void run() {
                    captureAndRead();
                }
            }, 170);
        } else {
            captureAndRead();
        }
    }

    private void captureAndRead() {
        int[] px = null;
        int w = 0, h = 0;
        try {
            Image img = held;
            if (img != null) {
                w = img.getWidth();
                h = img.getHeight();
                px = toArgb(img, w, h);
            }
        } catch (Throwable t) {
            px = null;
        }
        if (arrowShown) {
            ignoreUntil = SystemClock.elapsedRealtime() + 500;
            setArrowAlpha(1f);
        }
        try {
            if (px == null) {
                fail("Жду картинку с экрана…");
                return;
            }
            handleReading(BoardReader.read(px, w, h));
        } catch (Throwable t) {
            fail("Ошибка чтения: " + t);
        } finally {
            analyzing = false;
        }
    }

    private int[] toArgb(Image img, int w, int h) {
        Image.Plane plane = img.getPlanes()[0];
        ByteBuffer bb = plane.getBuffer();
        int strideInts = plane.getRowStride() / 4;
        IntBuffer ib = bb.order(ByteOrder.nativeOrder()).asIntBuffer();
        if (pxBuf == null || pxBuf.length != w * h) pxBuf = new int[w * h];
        int[] out = pxBuf;
        for (int y = 0; y < h; y++) {
            ib.position(y * strideInts);
            ib.get(out, y * w, w);
        }
        for (int i = 0; i < out.length; i++) {
            int p = out[i];   // байты R,G,B,A -> int 0xAABBGGRR
            out[i] = 0xFF000000 | ((p & 0xFF) << 16) | (p & 0xFF00) | ((p >> 16) & 0xFF);
        }
        return out;
    }

    // ============================================================ логика

    private void fail(String message) {
        committedFen = null;
        pendingFen = null;
        committedPos = null;
        if (engine != null) engine.cancel();
        clearArrows();
        setStatus(message);
        // не долбим процессор, пока доски нет на экране
        bg.postDelayed(new Runnable() {
            @Override
            public void run() {
                dirty = true;
            }
        }, 1000);
    }

    private void handleReading(BoardReader.Result r) {
        if (!r.ok) {
            fail(r.error);
            return;
        }
        final GameState.Position pos = state.build(r);
        if (pos == null) {
            fail(state.lastError);
            return;
        }
        main.post(new Runnable() {
            @Override
            public void run() {
                positionPanel(pos);
            }
        });
        if (pos.fen.equals(committedFen)) {
            pendingFen = null;
            return;
        }
        if (!pos.fen.equals(pendingFen)) {
            // позицию надо увидеть два раза подряд: так отсеиваются анимации и перетаскивание
            pendingFen = pos.fen;
            clearArrows();
            if (engine != null) engine.cancel();
            setStatus("Читаю доску…");
            dirty = true;
            return;
        }
        committedFen = pos.fen;
        pendingFen = null;
        committedPos = pos;
        if (!pos.userToMove) {
            clearArrows();
            if (engine != null) engine.cancel();
            setStatus("Ход соперника…");
            return;
        }
        if (engine == null) {
            setStatus("Позиция прочитана, но движка нет");
            return;
        }
        setStatus("Думаю…");
        engine.analyze(pos.fen, ANALYSIS_MS, 3, new StockfishEngine.Callback() {
            @Override
            public void onResult(final StockfishEngine.Result res) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        showResult(res);
                    }
                });
            }

            @Override
            public void onError(String msg) {
                setStatus(msg);
            }
        });
    }


    /** main */
    private void showResult(StockfishEngine.Result res) {
        GameState.Position p = committedPos;
        if (!running || p == null || !res.fen.equals(committedFen) || res.lines.length == 0) return;

        final int[] colors = {0xE62979FF, 0x99FF9800, 0x66FF9800};
        final float[] widths = {0.20f, 0.12f, 0.10f};
        ArrowView.Arrow[] arrows = new ArrowView.Arrow[res.lines.length];
        for (int i = 0; i < res.lines.length; i++) {
            String mv = res.lines[i].move;
            float[] a = center(p, mv.substring(0, 2));
            float[] b = center(p, mv.substring(2, 4));
            arrows[i] = new ArrowView.Arrow(a[0], a[1], b[0], b[1], colors[Math.min(i, 2)], widths[Math.min(i, 2)]);
        }
        StringBuilder sb = new StringBuilder();
        sb.append("▶ ").append(fmtMove(res.lines[0].move)).append("   ").append(fmtScore(res.lines[0]))
                .append("   (глубина ").append(res.depth).append(")");
        for (int i = 1; i < res.lines.length; i++) {
            sb.append(i == 1 ? "\n" : "    ").append(i + 1).append(") ").append(fmtMove(res.lines[i].move))
                    .append(' ').append(fmtScore(res.lines[i]));
        }
        ignoreUntil = SystemClock.elapsedRealtime() + 700;
        arrowShown = true;
        arrowView.setAlpha(1f);
        arrowView.setArrows(arrows, p.cell);
        statusTv.setText(sb.toString());
    }

    private static float[] center(GameState.Position p, String sq) {
        int f = sq.charAt(0) - 'a';
        int rk = sq.charAt(1) - '1';
        int col = p.whiteBottom ? f : 7 - f;
        int row = p.whiteBottom ? 7 - rk : rk;
        return new float[]{p.left + (col + 0.5f) * p.cell, p.top + (row + 0.5f) * p.cell};
    }

    private static String fmtMove(String m) {
        String s = m.substring(0, 2) + "→" + m.substring(2, 4);
        if (m.length() >= 5) s += "=" + Character.toUpperCase(m.charAt(4));
        return s;
    }

    private static String fmtScore(StockfishEngine.Line l) {
        if (l.mate) return l.mateIn > 0 ? "мат в " + l.mateIn : "мат против " + (-l.mateIn);
        return String.format(Locale.US, "%+.2f", l.cp / 100f);
    }

    // ============================================================ остановка

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (engine != null) engine.stop();
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (arrowView != null) wm.removeView(arrowView);
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (panel != null) wm.removeView(panel);
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (display != null) display.release();
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (projection != null) {
                if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
                projection.stop();
            }
        } catch (Throwable ignored) {
            // не важно
        }
        if (bg != null) {
            bg.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (held != null) held.close();
                        if (reader != null) reader.close();
                    } catch (Throwable ignored) {
                        // не важно
                    }
                    if (bgThread != null) bgThread.quitSafely();
                }
            });
        }
        super.onDestroy();
    }
}
