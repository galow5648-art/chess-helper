package com.chesshelper;

/**
 * Превращает результат распознавания (картинку) в позицию FEN.
 * Невидимое состояние восстанавливается так:
 *  - чей ход: по цвету фигуры на подсвеченной клетке последнего хода;
 *  - рокировка: фигуры стоят на начальных клетках, право только исчезает (до новой партии);
 *  - взятие на проходе: по подсветке хода пешки на две клетки;
 *  - ориентация: по тому, где стоят белые.
 */
public final class GameState {

    public static final class Position {
        public String fen;
        public boolean whiteBottom;
        public boolean whiteToMove;
        public boolean userToMove;
        public float left, top, cell;
    }

    public String lastError = "";

    private boolean orientKnown;
    private boolean whiteBottom = true;
    private boolean wk = true, wq = true, bk = true, bq = true;
    private String lastPlacement;
    private Boolean lastWhiteToMove;

    static final String START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

    public synchronized void flip() {
        whiteBottom = !whiteBottom;
        orientKnown = true;
        lastPlacement = null;
        lastWhiteToMove = null;
    }

    public synchronized void reset() {
        orientKnown = false;
        wk = wq = bk = bq = true;
        lastPlacement = null;
        lastWhiteToMove = null;
    }

    public synchronized boolean isWhiteBottom() {
        return whiteBottom;
    }

    /** @return позиция или null (тогда смотри lastError). */
    public synchronized Position build(BoardReader.Result r) {
        // 1. ориентация
        double wSum = 0, bSum = 0;
        int wN = 0, bN = 0;
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                char ch = r.sq[row][col];
                if (ch == '.') continue;
                if (Character.isUpperCase(ch)) { wSum += row; wN++; } else { bSum += row; bN++; }
            }
        }
        if (wN == 0 || bN == 0) {
            lastError = "На доске не видно обоих королей";
            return null;
        }
        boolean guessWhiteBottom = (wSum / wN) > (bSum / bN);

        // позиция в экранной ориентации -> строка FEN по гадаемой ориентации
        // (для определения "начальной позиции" ориентация гадается заново)
        char[][] bTry = toChess(r.sq, guessWhiteBottom);
        boolean isStart = placement(bTry).equals(START);
        if (isStart) {
            whiteBottom = guessWhiteBottom;
            orientKnown = true;
            wk = wq = bk = bq = true;
            lastPlacement = null;
            lastWhiteToMove = null;
        } else if (!orientKnown) {
            whiteBottom = guessWhiteBottom;
            orientKnown = true;
        }

        char[][] b = toChess(r.sq, whiteBottom);   // b[rank 0..7][file 0..7]; rank 0 = первая горизонталь
        boolean[][] h = toChessBool(r.hl, whiteBottom);

        // 2. базовая проверка
        int wkN = 0, bkN = 0;
        for (int rk = 0; rk < 8; rk++) {
            for (int f = 0; f < 8; f++) {
                char ch = b[rk][f];
                if (ch == 'K') wkN++;
                if (ch == 'k') bkN++;
                if ((ch == 'P' || ch == 'p') && (rk == 0 || rk == 7)) {
                    lastError = "Пешка на крайней горизонтали - не доверяю чтению";
                    return null;
                }
            }
        }
        if (wkN != 1 || bkN != 1) {
            lastError = "Не вижу обоих королей (" + wkN + "/" + bkN + ")";
            return null;
        }

        // 3. права на рокировку (только убывают)
        if (b[0][4] != 'K') { wk = false; wq = false; }
        if (b[0][7] != 'R') wk = false;
        if (b[0][0] != 'R') wq = false;
        if (b[7][4] != 'k') { bk = false; bq = false; }
        if (b[7][7] != 'r') bk = false;
        if (b[7][0] != 'r') bq = false;

        // 4. чей ход и взятие на проходе
        String plc = placement(b);
        int hlCount = 0;
        boolean sawW = false, sawB = false;
        int[][] hc = new int[64][2];
        for (int rk = 0; rk < 8; rk++) {
            for (int f = 0; f < 8; f++) {
                if (!h[rk][f]) continue;
                if (hlCount < 64) { hc[hlCount][0] = rk; hc[hlCount][1] = f; }
                hlCount++;
                char ch = b[rk][f];
                if (ch != '.') {
                    if (Character.isUpperCase(ch)) sawW = true; else sawB = true;
                }
            }
        }
        Boolean whiteToMove = null;
        if (hlCount >= 1 && hlCount <= 2 && (sawW ^ sawB)) whiteToMove = !sawW;   // сходил тот, чья фигура на подсвеченной клетке
        if (whiteToMove == null) {
            if (plc.equals(START)) whiteToMove = Boolean.TRUE;
            else if (plc.equals(lastPlacement) && lastWhiteToMove != null) whiteToMove = lastWhiteToMove;
            else whiteToMove = whiteBottom;    // нет подсветки: считаем, что ходит игрок (снизу)
        }
        lastPlacement = plc;
        lastWhiteToMove = whiteToMove;

        String ep = "-";
        if (hlCount == 2) {
            int r0 = hc[0][0], f0 = hc[0][1], r1 = hc[1][0], f1 = hc[1][1];
            if (f0 == f1 && Math.abs(r0 - r1) == 2) {
                int rd = (b[r0][f0] != '.') ? r0 : r1;   // клетка с пешкой
                int ro = (rd == r0) ? r1 : r0;
                char pc = b[rd][f0];
                if ((pc == 'P' && ro == 1 && rd == 3) || (pc == 'p' && ro == 6 && rd == 4)) {
                    ep = "" + (char) ('a' + f0) + (((ro + rd) / 2) + 1);
                }
            }
        }

        // 5. легальность "по-простому": сторона, не стоящая на ходу, не должна быть под шахом
        if (kingAttacked(b, !whiteToMove)) {
            lastError = "Позиция выглядит невозможной (шах стороне без хода)";
            return null;
        }

        StringBuilder castle = new StringBuilder();
        if (wk) castle.append('K');
        if (wq) castle.append('Q');
        if (bk) castle.append('k');
        if (bq) castle.append('q');
        if (castle.length() == 0) castle.append('-');

        Position p = new Position();
        p.fen = plc + (whiteToMove ? " w " : " b ") + castle + " " + ep + " 0 1";
        p.whiteBottom = whiteBottom;
        p.whiteToMove = whiteToMove;
        p.userToMove = (whiteToMove == whiteBottom);
        p.left = r.left;
        p.top = r.top;
        p.cell = r.cell;
        lastError = "";
        return p;
    }

    // ------------------------------------------------------------- утилиты

    static char[][] toChess(char[][] sq, boolean whiteBottom) {
        char[][] b = new char[8][8];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                int rk = whiteBottom ? 7 - row : row;
                int f = whiteBottom ? col : 7 - col;
                b[rk][f] = sq[row][col];
            }
        }
        return b;
    }

    static boolean[][] toChessBool(boolean[][] sq, boolean whiteBottom) {
        boolean[][] b = new boolean[8][8];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                int rk = whiteBottom ? 7 - row : row;
                int f = whiteBottom ? col : 7 - col;
                b[rk][f] = sq[row][col];
            }
        }
        return b;
    }

    static String placement(char[][] b) {
        StringBuilder sb = new StringBuilder();
        for (int rk = 7; rk >= 0; rk--) {
            int e = 0;
            for (int f = 0; f < 8; f++) {
                char ch = b[rk][f];
                if (ch == '.') {
                    e++;
                } else {
                    if (e > 0) sb.append(e);
                    e = 0;
                    sb.append(ch);
                }
            }
            if (e > 0) sb.append(e);
            if (rk > 0) sb.append('/');
        }
        return sb.toString();
    }

    private static char at(char[][] b, int rk, int f) {
        if (rk < 0 || rk > 7 || f < 0 || f > 7) return 0;
        return b[rk][f];
    }

    /** Стоит ли король указанного цвета под боем. */
    static boolean kingAttacked(char[][] b, boolean white) {
        char king = white ? 'K' : 'k';
        int kr = -1, kf = -1;
        for (int rk = 0; rk < 8; rk++) for (int f = 0; f < 8; f++) if (b[rk][f] == king) { kr = rk; kf = f; }
        if (kr < 0) return false;
        // пешки противника
        char pawn = white ? 'p' : 'P';
        int pr = white ? kr + 1 : kr - 1;
        if (at(b, pr, kf - 1) == pawn || at(b, pr, kf + 1) == pawn) return true;
        // кони
        char knight = white ? 'n' : 'N';
        int[][] kn = {{1, 2}, {2, 1}, {-1, 2}, {-2, 1}, {1, -2}, {2, -1}, {-1, -2}, {-2, -1}};
        for (int[] d : kn) if (at(b, kr + d[0], kf + d[1]) == knight) return true;
        // король
        char ek = white ? 'k' : 'K';
        for (int dr = -1; dr <= 1; dr++) for (int df = -1; df <= 1; df++) {
            if ((dr != 0 || df != 0) && at(b, kr + dr, kf + df) == ek) return true;
        }
        // слоны/ладьи/ферзи
        char rook = white ? 'r' : 'R', bish = white ? 'b' : 'B', queen = white ? 'q' : 'Q';
        int[][] ortho = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        int[][] diag = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        for (int[] d : ortho) {
            int rr = kr + d[0], ff = kf + d[1];
            while (at(b, rr, ff) == '.') { rr += d[0]; ff += d[1]; }
            char c = at(b, rr, ff);
            if (c == rook || c == queen) return true;
        }
        for (int[] d : diag) {
            int rr = kr + d[0], ff = kf + d[1];
            while (at(b, rr, ff) == '.') { rr += d[0]; ff += d[1]; }
            char c = at(b, rr, ff);
            if (c == bish || c == queen) return true;
        }
        return false;
    }
}
