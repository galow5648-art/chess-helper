package com.chesshelper;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 1001;
    private TextView status;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFF1E1E1E);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(32), dp(20), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Шахматный помощник");
        title.setTextSize(24);
        title.setTextColor(0xFFFFFFFF);
        root.addView(title);

        TextView about = new TextView(this);
        about.setText("Смотрит на экран, читает доску Chess.com и рисует поверх неё стрелку лучшего хода "
                + "(движок Stockfish работает прямо на телефоне, интернет не нужен).\n\n"
                + "Как пользоваться:\n"
                + "1. Нажми «Запустить» и разреши показ поверх других приложений и запись экрана "
                + "(выбери «Весь экран»).\n"
                + "2. Открой Chess.com и начни партию с ботом.\n"
                + "3. Когда твой ход, появится стрелка и подсказка в панели. ⇅ - перевернуть ориентацию, "
                + "если она определилась неверно, ✕ - выключить.\n\n"
                + "Работает со стандартной зелёной доской и стандартными фигурами Chess.com, "
                + "портретная ориентация.\n\n"
                + "ТОЛЬКО для игры с ботами, тренировки и разбора. "
                + "В партиях против живых людей помощь движка - нечестная игра и ведёт к бану.");
        about.setTextSize(15);
        about.setTextColor(0xFFCCCCCC);
        about.setPadding(0, dp(12), 0, dp(16));
        root.addView(about);

        status = new TextView(this);
        status.setTextSize(14);
        status.setTextColor(0xFFFFC107);
        status.setPadding(0, 0, 0, dp(16));
        root.addView(status);

        Button start = new Button(this);
        start.setText("Запустить помощника");
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startHelper();
            }
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Остановить");
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, AssistService.class);
                i.setAction(AssistService.ACTION_STOP);
                startService(i);
            }
        });
        root.addView(stop);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        StringBuilder sb = new StringBuilder();
        if (!Settings.canDrawOverlays(this)) sb.append("• Нужно разрешение «Поверх других приложений».\n");
        File sf = new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so");
        if (!sf.exists()) sb.append("• В приложении нет движка Stockfish (сборка прошла без него).\n");
        status.setText(sb.length() == 0 ? "Всё готово к запуску." : sb.toString());
    }

    private void startHelper() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разреши показ поверх других приложений и вернись назад", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent i = new Intent(this, AssistService.class);
                i.putExtra("code", resultCode);
                i.putExtra("data", data);
                startForegroundService(i);
                moveTaskToBack(true);
            } else {
                Toast.makeText(this, "Без записи экрана помощник работать не может", Toast.LENGTH_LONG).show();
            }
        }
    }
}
