package com.chesshelper;

/**
 * Читает шахматную доску Chess.com (стандартная зелёная тема и стандартные фигуры)
 * из массива пикселей ARGB. Не зависит от Android, поэтому легко тестируется.
 */
public final class BoardReader {

    /** Размер сетки покрытия клетки (G x G). */
    public static final int G = 24;
    public static final String ORDER = "KQRBNP";

    private static final int NEUTRAL = 14;          // max(R,G,B)-min(R,G,B) не больше: пиксель "серый" = фигура
    private static final float EMPTY_THRESH = 0.08f; // доля "фигурных" пикселей в центре клетки
    private static final float LUM_SPLIT = 130f;     // средняя яркость: ниже - чёрная фигура
    private static final float MAX_DIST = 0.16f;     // максимально допустимое отличие от шаблона

    public static final class Result {
        public boolean ok;
        public String error = "";
        public float left, top, cell;
        /** Экранная ориентация: [строка сверху][столбец слева], '.' = пусто. */
        public final char[][] sq = new char[8][8];
        public final boolean[][] hl = new boolean[8][8];
        public float worstDist;
    }

    public static final class Cell {
        public boolean piece;
        public boolean hl;
        public float fgFrac;
        public float meanLum;
        public final float[] cov = new float[G * G];
    }

    private final int[] px;
    private final int w, h;

    public BoardReader(int[] px, int w, int h) {
        this.px = px;
        this.w = w;
        this.h = h;
    }

    // ---------------------------------------------------------------- цвета

    private static boolean near(int r, int g, int b, int rr, int gg, int bb, int tol) {
        return Math.abs(r - rr) + Math.abs(g - gg) + Math.abs(b - bb) < tol;
    }

    static boolean isHighlightRgb(int r, int g, int b) {
        return r > 165 && g > 185 && b < 160 && (r - b) > 70 && Math.abs(r - g) < 40;
    }

    private static boolean isBoardColor(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        return near(r, g, b, 118, 150, 86, 36)
                || near(r, g, b, 238, 238, 210, 36)
                || isHighlightRgb(r, g, b);
    }

    private int get(int x, int y) {
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x >= w) x = w - 1;
        if (y >= h) y = h - 1;
        return px[y * w + x];
    }

    // -------------------------------------------------------- поиск доски

    /** Возвращает {left, top, cell} или null. */
    public float[] locate() {
        final int step = 2;
        int ny = h / step, nx = w / step;
        int[] rowCnt = new int[ny];
        int maxRow = 0;
        for (int yi = 0; yi < ny; yi++) {
            int y = yi * step, c = 0;
            int base = y * w;
            for (int xi = 0; xi < nx; xi++) {
                if (isBoardColor(px[base + xi * step])) c++;
            }
            rowCnt[yi] = c;
            if (c > maxRow) maxRow = c;
        }
        if (maxRow < 20) return null;
        int[] vr = longestRun(rowCnt, (int) (maxRow * 0.2f));
        if (vr == null) return null;
        int top = vr[0] * step;
        int bottom = (vr[1] + 1) * step;

        int[] colCnt = new int[nx];
        int maxCol = 0;
        for (int xi = 0; xi < nx; xi++) {
            int x = xi * step, c = 0;
            for (int yi = vr[0]; yi <= vr[1]; yi++) {
                if (isBoardColor(px[yi * step * w + x])) c++;
            }
            colCnt[xi] = c;
            if (c > maxCol) maxCol = c;
        }
        if (maxCol < 20) return null;
        int[] hr = longestRun(colCnt, (int) (maxCol * 0.2f));
        if (hr == null) return null;
        int left = hr[0] * step;
        int right = (hr[1] + 1) * step;

        int bh = bottom - top, bw = right - left;
        if (bh < 200 || bw < 200) return null;
        if (Math.abs(bh - bw) > 0.04f * Math.max(bh, bw)) return null;
        float side = (bh + bw) / 2f;
        return new float[]{left, top, side / 8f};
    }

    /** Самая длинная полоса индексов с cnt >= thr; разрывы до 3 индексов (границы клеток) прощаются. */
    private static int[] longestRun(int[] cnt, int thr) {
        final int maxGap = 3;
        int bestS = -1, bestE = -1;
        int s = -1, last = -1;
        for (int i = 0; i <= cnt.length; i++) {
            boolean on = i < cnt.length && cnt[i] >= thr && cnt[i] > 0;
            if (on) {
                if (s < 0) s = i;
                last = i;
            } else if (s >= 0 && (i >= cnt.length || i - last > maxGap)) {
                if (bestS < 0 || (last - s) > (bestE - bestS)) {
                    bestS = s;
                    bestE = last;
                }
                s = -1;
            }
        }
        return bestS < 0 ? null : new int[]{bestS, bestE};
    }

    // ------------------------------------------------------ анализ клетки

    private int[] background(float x0, float y0, float cell) {
        final float[] fx = {0.06f, 0.94f, 0.06f, 0.94f, 0.06f, 0.94f};
        final float[] fy = {0.35f, 0.35f, 0.50f, 0.50f, 0.65f, 0.65f};
        int[] rs = new int[6], gs = new int[6], bs = new int[6];
        for (int i = 0; i < 6; i++) {
            int p = get((int) (x0 + fx[i] * cell), (int) (y0 + fy[i] * cell));
            rs[i] = (p >> 16) & 255;
            gs[i] = (p >> 8) & 255;
            bs[i] = p & 255;
        }
        java.util.Arrays.sort(rs);
        java.util.Arrays.sort(gs);
        java.util.Arrays.sort(bs);
        return new int[]{(rs[2] + rs[3]) / 2, (gs[2] + gs[3]) / 2, (bs[2] + bs[3]) / 2};
    }

    public Cell analyzeCell(float left, float top, float cell, int r, int c) {
        float x0 = left + c * cell, y0 = top + r * cell;
        int[] bg = background(x0, y0, cell);
        Cell out = new Cell();
        out.hl = isHighlightRgb(bg[0], bg[1], bg[2]);

        final float crop0 = 0.10f, cropSize = 0.80f;
        float gs = cropSize * cell / G;
        int lo = (int) (G * 0.15f), hi = (int) (G * 0.85f);
        double lumSum = 0;
        int lumN = 0, innerFg = 0, innerN = 0;
        for (int gy = 0; gy < G; gy++) {
            for (int gx = 0; gx < G; gx++) {
                int cnt = 0;
                boolean inner = gx >= lo && gx < hi && gy >= lo && gy < hi;
                for (int sy = 0; sy < 3; sy++) {
                    for (int sx = 0; sx < 3; sx++) {
                        float fx = x0 + crop0 * cell + (gx + (sx + 0.5f) / 3f) * gs;
                        float fy = y0 + crop0 * cell + (gy + (sy + 0.5f) / 3f) * gs;
                        int p = get((int) fx, (int) fy);
                        int rr = (p >> 16) & 255, gg = (p >> 8) & 255, bb = p & 255;
                        int mx = Math.max(rr, Math.max(gg, bb)), mn = Math.min(rr, Math.min(gg, bb));
                        boolean f = (mx - mn) <= NEUTRAL;
                        if (f) cnt++;
                        if (inner) {
                            innerN++;
                            if (f) {
                                innerFg++;
                                lumSum += 0.299 * rr + 0.587 * gg + 0.114 * bb;
                                lumN++;
                            }
                        }
                    }
                }
                out.cov[gy * G + gx] = cnt / 9f;
            }
        }
        out.fgFrac = innerFg / (float) innerN;
        out.meanLum = lumN > 0 ? (float) (lumSum / lumN) : 0f;
        out.piece = out.fgFrac > EMPTY_THRESH;
        return out;
    }

    // ------------------------------------------------------ шаблоны

    private static float[][] tpl;

    private static synchronized float[][] templates() {
        if (tpl == null) {
            String[] d = Templates.DATA;
            float[][] t = new float[d.length][G * G];
            for (int i = 0; i < d.length; i++) {
                String s = d[i];
                for (int k = 0; k < G * G; k++) t[i][k] = (s.charAt(k) - '0') / 9f;
            }
            tpl = t;
        }
        return tpl;
    }

    /** @return {индекс типа 0..5, расстояние} среди шаблонов нужного цвета. */
    static float[] classify(float[] cov, boolean white) {
        float[][] t = templates();
        int best = -1;
        float bd = 1e9f;
        for (int ty = 0; ty < 6; ty++) {
            float[] tp = t[(white ? 0 : 6) + ty];
            float s = 0;
            for (int k = 0; k < G * G; k++) s += Math.abs(cov[k] - tp[k]);
            s /= (G * G);
            if (s < bd) {
                bd = s;
                best = ty;
            }
        }
        return new float[]{best, bd};
    }

    // ------------------------------------------------------ главный метод

    public static Result read(int[] px, int w, int h) {
        Result res = new Result();
        BoardReader br = new BoardReader(px, w, h);
        float[] loc = br.locate();
        if (loc == null) {
            res.error = "Доска не найдена на экране";
            return res;
        }
        res.left = loc[0];
        res.top = loc[1];
        res.cell = loc[2];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                Cell cl = br.analyzeCell(res.left, res.top, res.cell, r, c);
                res.hl[r][c] = cl.hl;
                if (!cl.piece) {
                    res.sq[r][c] = '.';
                    continue;
                }
                boolean white = cl.meanLum >= LUM_SPLIT;
                float[] m = classify(cl.cov, white);
                if (m[1] > res.worstDist) res.worstDist = m[1];
                if (m[1] > MAX_DIST) {
                    res.error = "Не узнаю фигуру (клетка " + (char) ('a' + c) + (8 - r) + ")";
                    return res;
                }
                char ch = ORDER.charAt((int) m[0]);
                res.sq[r][c] = white ? ch : Character.toLowerCase(ch);
            }
        }
        res.ok = true;
        return res;
    }
}
