Шахматный помощник (Android, Java, без внешних библиотек)

  app/src/main/java/com/chesshelper/
    BoardFinder.java    - ищет доску как шахматную решётку 8x8 (любая тема), уточняет по рёбрам
    BoardReader.java    - читает фигуры (шаблоны силуэтов, Templates.java), помечает неузнанные как '?'
    Chess.java          - правила: легальные ходы, FEN, SAN (проверено perft-тестами)
    GameState.java      - слежение за партией по легальным ходам, история ходов, ориентация
    StockfishEngine.java- обёртка над UCI-процессом Stockfish, промежуточные результаты
    AssistService.java  - захват экрана, оверлей, главный цикл
    CalibView.java      - ручная калибровка рамки доски
    ArrowView.java      - стрелки ходов
    MainActivity.java   - запуск и разрешения
  Stockfish кладётся в app/src/main/jniLibs/arm64-v8a/libstockfish.so (это делает build.yml).
