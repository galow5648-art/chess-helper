package com.chesshelper;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/**
 * Ручная калибровка: пользователь двигает жёлтую рамку и тянет за кружок в правом нижнем углу,
 * чтобы рамка совпала с доской. Запасной вариант, если автоопределение не справилось.
 */
public final class CalibView extends View {

    public interface Listener {
        void onDone(float left, float top, float side, boolean auto);
    }

    private float left, top, side;
    private final Listener listener;
    private final float dp;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] loc = new int[2];
    private int mode;               // 0 нет, 1 двигаем, 2 тянем размер
    private float lastX, lastY;
    private final float[] okRect = new float[4];
    private final float[] autoRect = new float[4];

    public CalibView(Context context, float left, float top, float side, float density, Listener l) {
        super(context);
        this.left = left;
        this.top = top;
        this.side = side;
        this.dp = density;
        this.listener = l;
    }

    @Override
    protected void onDraw(Canvas c) {
        getLocationOnScreen(loc);
        float ox = loc[0], oy = loc[1];
        float sw = getWidth(), sh = getHeight();
        c.translate(-ox, -oy);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x55000000);
        c.drawRect(ox, oy, ox + sw, oy + sh, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp);
        paint.setColor(0xCCFFEB3B);
        float cell = side / 8f;
        for (int i = 1; i < 8; i++) {
            c.drawLine(left + i * cell, top, left + i * cell, top + side, paint);
            c.drawLine(left, top + i * cell, left + side, top + i * cell, paint);
        }
        paint.setStrokeWidth(3 * dp);
        paint.setColor(0xFFFFEB3B);
        c.drawRect(left, top, left + side, top + side, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFFFFEB3B);
        c.drawCircle(left + side, top + side, 16 * dp, paint);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(16 * dp);
        paint.setColor(0xFFFFFFFF);
        c.drawText("Совмести рамку с доской:", ox + sw / 2, oy + 70 * dp, paint);
        c.drawText("двигай внутри, тяни за жёлтый кружок", ox + sw / 2, oy + 94 * dp, paint);

        float by = oy + sh - 110 * dp, bh = 52 * dp;
        okRect[0] = ox + sw / 2 + 10 * dp; okRect[1] = by; okRect[2] = okRect[0] + 130 * dp; okRect[3] = by + bh;
        autoRect[0] = ox + sw / 2 - 140 * dp; autoRect[1] = by; autoRect[2] = autoRect[0] + 130 * dp; autoRect[3] = by + bh;
        paint.setColor(0xFF2E7D32);
        c.drawRect(okRect[0], okRect[1], okRect[2], okRect[3], paint);
        paint.setColor(0xFF455A64);
        c.drawRect(autoRect[0], autoRect[1], autoRect[2], autoRect[3], paint);
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(18 * dp);
        c.drawText("Готово", (okRect[0] + okRect[2]) / 2, by + bh / 2 + 6 * dp, paint);
        c.drawText("Авто", (autoRect[0] + autoRect[2]) / 2, by + bh / 2 + 6 * dp, paint);
    }

    private static boolean in(float[] r, float x, float y) {
        return x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3];
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        float x = ev.getRawX(), y = ev.getRawY();
        int a = ev.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            if (in(okRect, x, y)) {
                listener.onDone(left, top, side, false);
                return true;
            }
            if (in(autoRect, x, y)) {
                listener.onDone(left, top, side, true);
                return true;
            }
            float dx = x - (left + side), dy = y - (top + side);
            if (Math.hypot(dx, dy) < 40 * dp) mode = 2;
            else if (x >= left && x <= left + side && y >= top && y <= top + side) mode = 1;
            else mode = 0;
            lastX = x;
            lastY = y;
        } else if (a == MotionEvent.ACTION_MOVE) {
            float dx = x - lastX, dy = y - lastY;
            if (mode == 1) {
                left += dx;
                top += dy;
            } else if (mode == 2) {
                side = Math.max(120 * dp, side + (dx + dy) / 2f);
            }
            lastX = x;
            lastY = y;
            invalidate();
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            mode = 0;
        }
        return true;
    }
}
