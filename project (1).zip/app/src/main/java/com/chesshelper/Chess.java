package com.chesshelper;

import java.util.ArrayList;
import java.util.List;

/** Шахматные правила: генерация легальных ходов, применение хода, FEN, SAN. Без зависимостей от Android. */
public final class Chess {
    private Chess() {}

    /** Позиция. Индекс клетки = горизонталь*8 + вертикаль (a1=0, h1=7, a8=56). */
    public static final class Pos {
        public final char[] b = new char[64];
        public boolean white = true;
        public boolean wk, wq, bk, bq;
        public int ep = -1;
        public int half = 0, full = 1;

        public Pos copy() {
            Pos p = new Pos();
            System.arraycopy(b, 0, p.b, 0, 64);
            p.white = white;
            p.wk = wk;
            p.wq = wq;
            p.bk = bk;
            p.bq = bq;
            p.ep = ep;
            p.half = half;
            p.full = full;
            return p;
        }
    }

    public static final class Move {
        public final int from, to;
        public final char promo;   // 0 или q r b n (строчная)

        public Move(int from, int to, char promo) {
            this.from = from;
            this.to = to;
            this.promo = promo;
        }

        public String uci() {
            return name(from) + name(to) + (promo != 0 ? String.valueOf(promo) : "");
        }
    }

    public static String name(int s) {
        return "" + (char) ('a' + (s & 7)) + (char) ('1' + (s >> 3));
    }

    public static int square(String n) {
        return (n.charAt(1) - '1') * 8 + (n.charAt(0) - 'a');
    }

    public static boolean isWhite(char c) {
        return c >= 'A' && c <= 'Z';
    }

    private static final int[][] KN = {{1, 2}, {2, 1}, {-1, 2}, {-2, 1}, {1, -2}, {2, -1}, {-1, -2}, {-2, -1}};
    private static final int[][] DIAG = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
    private static final int[][] ORTHO = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final char[] PROMOS = {'q', 'r', 'b', 'n'};

    // ------------------------------------------------------------ атаки

    /** Бьёт ли сторона byWhite клетку sq. */
    public static boolean attacked(Pos p, int sq, boolean byWhite) {
        int r = sq >> 3, f = sq & 7;
        char pawn = byWhite ? 'P' : 'p';
        int pr = byWhite ? r - 1 : r + 1;
        if (pr >= 0 && pr < 8) {
            if (f > 0 && p.b[pr * 8 + f - 1] == pawn) return true;
            if (f < 7 && p.b[pr * 8 + f + 1] == pawn) return true;
        }
        char kn = byWhite ? 'N' : 'n';
        for (int[] d : KN) {
            int rr = r + d[0], ff = f + d[1];
            if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && p.b[rr * 8 + ff] == kn) return true;
        }
        char kg = byWhite ? 'K' : 'k';
        for (int dr = -1; dr <= 1; dr++) {
            for (int df = -1; df <= 1; df++) {
                if (dr == 0 && df == 0) continue;
                int rr = r + dr, ff = f + df;
                if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && p.b[rr * 8 + ff] == kg) return true;
            }
        }
        char rk = byWhite ? 'R' : 'r', bs = byWhite ? 'B' : 'b', qn = byWhite ? 'Q' : 'q';
        for (int[] d : ORTHO) {
            int rr = r + d[0], ff = f + d[1];
            while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
                char c = p.b[rr * 8 + ff];
                if (c != '.') {
                    if (c == rk || c == qn) return true;
                    break;
                }
                rr += d[0];
                ff += d[1];
            }
        }
        for (int[] d : DIAG) {
            int rr = r + d[0], ff = f + d[1];
            while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
                char c = p.b[rr * 8 + ff];
                if (c != '.') {
                    if (c == bs || c == qn) return true;
                    break;
                }
                rr += d[0];
                ff += d[1];
            }
        }
        return false;
    }

    public static boolean inCheck(Pos p, boolean white) {
        char k = white ? 'K' : 'k';
        for (int s = 0; s < 64; s++) {
            if (p.b[s] == k) return attacked(p, s, !white);
        }
        return false;
    }

    // ------------------------------------------------------------ ходы

    private static void addPawnMove(List<Move> out, int from, int to, boolean white) {
        int tr = to >> 3;
        if (tr == 7 || tr == 0) {
            for (char pc : PROMOS) out.add(new Move(from, to, pc));
        } else {
            out.add(new Move(from, to, (char) 0));
        }
    }

    private static void pseudo(Pos p, List<Move> out) {
        boolean w = p.white;
        for (int s = 0; s < 64; s++) {
            char c = p.b[s];
            if (c == '.' || isWhite(c) != w) continue;
            int r = s >> 3, f = s & 7;
            char t = Character.toUpperCase(c);
            if (t == 'P') {
                int dir = w ? 1 : -1;
                int one = s + 8 * dir;
                if (one >= 0 && one < 64 && p.b[one] == '.') {
                    addPawnMove(out, s, one, w);
                    int startRank = w ? 1 : 6;
                    int two = s + 16 * dir;
                    if (r == startRank && p.b[two] == '.') out.add(new Move(s, two, (char) 0));
                }
                for (int df = -1; df <= 1; df += 2) {
                    int nf = f + df;
                    int nr = r + dir;
                    if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
                    int to = nr * 8 + nf;
                    char tc = p.b[to];
                    if (tc != '.' && isWhite(tc) != w) {
                        addPawnMove(out, s, to, w);
                    } else if (tc == '.' && to == p.ep) {
                        char victim = p.b[w ? to - 8 : to + 8];
                        if (victim == (w ? 'p' : 'P')) out.add(new Move(s, to, (char) 0));
                    }
                }
            } else if (t == 'N') {
                for (int[] d : KN) {
                    int rr = r + d[0], ff = f + d[1];
                    if (rr < 0 || rr > 7 || ff < 0 || ff > 7) continue;
                    char tc = p.b[rr * 8 + ff];
                    if (tc == '.' || isWhite(tc) != w) out.add(new Move(s, rr * 8 + ff, (char) 0));
                }
            } else if (t == 'K') {
                for (int dr = -1; dr <= 1; dr++) {
                    for (int df = -1; df <= 1; df++) {
                        if (dr == 0 && df == 0) continue;
                        int rr = r + dr, ff = f + df;
                        if (rr < 0 || rr > 7 || ff < 0 || ff > 7) continue;
                        char tc = p.b[rr * 8 + ff];
                        if (tc == '.' || isWhite(tc) != w) out.add(new Move(s, rr * 8 + ff, (char) 0));
                    }
                }
                if (w && s == 4) {
                    if (p.wk && p.b[7] == 'R' && p.b[5] == '.' && p.b[6] == '.'
                            && !attacked(p, 4, false) && !attacked(p, 5, false) && !attacked(p, 6, false)) {
                        out.add(new Move(4, 6, (char) 0));
                    }
                    if (p.wq && p.b[0] == 'R' && p.b[1] == '.' && p.b[2] == '.' && p.b[3] == '.'
                            && !attacked(p, 4, false) && !attacked(p, 3, false) && !attacked(p, 2, false)) {
                        out.add(new Move(4, 2, (char) 0));
                    }
                } else if (!w && s == 60) {
                    if (p.bk && p.b[63] == 'r' && p.b[61] == '.' && p.b[62] == '.'
                            && !attacked(p, 60, true) && !attacked(p, 61, true) && !attacked(p, 62, true)) {
                        out.add(new Move(60, 62, (char) 0));
                    }
                    if (p.bq && p.b[56] == 'r' && p.b[57] == '.' && p.b[58] == '.' && p.b[59] == '.'
                            && !attacked(p, 60, true) && !attacked(p, 59, true) && !attacked(p, 58, true)) {
                        out.add(new Move(60, 58, (char) 0));
                    }
                }
            } else {
                boolean diag = (t == 'B' || t == 'Q'), ortho = (t == 'R' || t == 'Q');
                if (diag) slide(p, out, s, DIAG, w);
                if (ortho) slide(p, out, s, ORTHO, w);
            }
        }
    }

    private static void slide(Pos p, List<Move> out, int s, int[][] dirs, boolean w) {
        int r = s >> 3, f = s & 7;
        for (int[] d : dirs) {
            int rr = r + d[0], ff = f + d[1];
            while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
                char tc = p.b[rr * 8 + ff];
                if (tc == '.') {
                    out.add(new Move(s, rr * 8 + ff, (char) 0));
                } else {
                    if (isWhite(tc) != w) out.add(new Move(s, rr * 8 + ff, (char) 0));
                    break;
                }
                rr += d[0];
                ff += d[1];
            }
        }
    }

    public static List<Move> legal(Pos p) {
        List<Move> ps = new ArrayList<Move>(48);
        pseudo(p, ps);
        List<Move> out = new ArrayList<Move>(ps.size());
        for (Move m : ps) {
            Pos q = apply(p, m);
            if (!inCheck(q, p.white)) out.add(m);
        }
        return out;
    }

    public static Pos apply(Pos p, Move m) {
        Pos q = p.copy();
        char c = q.b[m.from];
        char cap = q.b[m.to];
        char t = Character.toUpperCase(c);
        boolean pawn = t == 'P';
        q.b[m.to] = c;
        q.b[m.from] = '.';
        if (pawn && m.to == p.ep && cap == '.' && (m.from & 7) != (m.to & 7)) {
            q.b[p.white ? m.to - 8 : m.to + 8] = '.';
            cap = 'x';
        }
        if (m.promo != 0) q.b[m.to] = p.white ? Character.toUpperCase(m.promo) : m.promo;
        if (t == 'K' && Math.abs((m.to & 7) - (m.from & 7)) == 2) {
            if (m.to == 6) { q.b[5] = q.b[7]; q.b[7] = '.'; }
            else if (m.to == 2) { q.b[3] = q.b[0]; q.b[0] = '.'; }
            else if (m.to == 62) { q.b[61] = q.b[63]; q.b[63] = '.'; }
            else if (m.to == 58) { q.b[59] = q.b[56]; q.b[56] = '.'; }
        }
        if (c == 'K') { q.wk = false; q.wq = false; }
        if (c == 'k') { q.bk = false; q.bq = false; }
        if (m.from == 0 || m.to == 0) q.wq = false;
        if (m.from == 7 || m.to == 7) q.wk = false;
        if (m.from == 56 || m.to == 56) q.bq = false;
        if (m.from == 63 || m.to == 63) q.bk = false;
        q.ep = (pawn && Math.abs(m.to - m.from) == 16) ? (m.from + m.to) / 2 : -1;
        q.half = (pawn || cap != '.') ? 0 : p.half + 1;
        if (!p.white) q.full = p.full + 1;
        q.white = !p.white;
        return q;
    }

    // ------------------------------------------------------------ FEN

    public static String placement(Pos p) {
        StringBuilder sb = new StringBuilder();
        for (int r = 7; r >= 0; r--) {
            int e = 0;
            for (int f = 0; f < 8; f++) {
                char c = p.b[r * 8 + f];
                if (c == '.') {
                    e++;
                } else {
                    if (e > 0) sb.append(e);
                    e = 0;
                    sb.append(c);
                }
            }
            if (e > 0) sb.append(e);
            if (r > 0) sb.append('/');
        }
        return sb.toString();
    }

    public static String fen(Pos p) {
        StringBuilder sb = new StringBuilder(placement(p));
        sb.append(p.white ? " w " : " b ");
        int len = sb.length();
        if (p.wk) sb.append('K');
        if (p.wq) sb.append('Q');
        if (p.bk) sb.append('k');
        if (p.bq) sb.append('q');
        if (sb.length() == len) sb.append('-');
        sb.append(' ').append(p.ep >= 0 ? name(p.ep) : "-");
        sb.append(' ').append(p.half).append(' ').append(p.full);
        return sb.toString();
    }

    public static Pos fromFen(String fen) {
        String[] t = fen.trim().split("\\s+");
        Pos p = new Pos();
        java.util.Arrays.fill(p.b, '.');
        String[] rows = t[0].split("/");
        for (int i = 0; i < 8; i++) {
            int r = 7 - i, f = 0;
            for (char c : rows[i].toCharArray()) {
                if (c >= '1' && c <= '8') f += c - '0';
                else p.b[r * 8 + f++] = c;
            }
        }
        p.white = t.length < 2 || t[1].equals("w");
        String cs = t.length > 2 ? t[2] : "-";
        p.wk = cs.indexOf('K') >= 0;
        p.wq = cs.indexOf('Q') >= 0;
        p.bk = cs.indexOf('k') >= 0;
        p.bq = cs.indexOf('q') >= 0;
        p.ep = (t.length > 3 && !t[3].equals("-")) ? square(t[3]) : -1;
        p.half = t.length > 4 ? Integer.parseInt(t[4]) : 0;
        p.full = t.length > 5 ? Integer.parseInt(t[5]) : 1;
        return p;
    }

    public static Move parseUci(Pos p, String uci) {
        if (uci == null || uci.length() < 4) return null;
        for (Move m : legal(p)) if (m.uci().equals(uci)) return m;
        return null;
    }

    // ------------------------------------------------------------ SAN

    public static String san(Pos p, Move m, List<Move> legal) {
        char c = p.b[m.from];
        char t = Character.toUpperCase(c);
        StringBuilder sb = new StringBuilder();
        if (t == 'K' && Math.abs((m.to & 7) - (m.from & 7)) == 2) {
            sb.append((m.to & 7) == 6 ? "O-O" : "O-O-O");
        } else {
            boolean capture = p.b[m.to] != '.' || (t == 'P' && m.to == p.ep && (m.from & 7) != (m.to & 7));
            if (t != 'P') {
                sb.append(t);
                boolean amb = false, sameFile = false, sameRank = false;
                for (Move o : legal) {
                    if (o.from != m.from && o.to == m.to && p.b[o.from] == c) {
                        amb = true;
                        if ((o.from & 7) == (m.from & 7)) sameFile = true;
                        if ((o.from >> 3) == (m.from >> 3)) sameRank = true;
                    }
                }
                if (amb) {
                    if (!sameFile) sb.append((char) ('a' + (m.from & 7)));
                    else if (!sameRank) sb.append((char) ('1' + (m.from >> 3)));
                    else sb.append(name(m.from));
                }
            } else if (capture) {
                sb.append((char) ('a' + (m.from & 7)));
            }
            if (capture) sb.append('x');
            sb.append(name(m.to));
            if (m.promo != 0) sb.append('=').append(Character.toUpperCase(m.promo));
        }
        Pos q = apply(p, m);
        if (inCheck(q, q.white)) sb.append(legal(q).isEmpty() ? '#' : '+');
        return sb.toString();
    }

    // ------------------------------------------------------------ тесты

    public static long perft(Pos p, int depth) {
        if (depth == 0) return 1;
        List<Move> ms = legal(p);
        if (depth == 1) return ms.size();
        long n = 0;
        for (Move m : ms) n += perft(apply(p, m), depth - 1);
        return n;
    }
}
