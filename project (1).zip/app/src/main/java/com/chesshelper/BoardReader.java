package com.chesshelper;

/**
 * Читает шахматную доску (стандартные фигуры, любая двухцветная тема доски) из пикселей ARGB.
 * Не зависит от Android.
 */
public final class BoardReader {

    /** Размер сетки покрытия клетки (G x G). */
    public static final int G = 24;
    public static final String ORDER = "KQRBNP";

    private static final float EMPTY_THRESH = 0.08f;   // доля "фигурных" пикселей в центре клетки
    private static final float WHITE_LUM = 150f;       // яркость середины фигуры: выше - белая
    private static final float MAX_DIST = 0.09f;       // уверенное совпадение с шаблоном (после размытия)
    private static final float MAX_DIST_LOOSE = 0.30f; // допустимо, если явно лучше остальных типов
    private static final float MARGIN = 1.5f;          // во сколько раз второй тип должен быть хуже
    private static final int MAX_UNKNOWN = 6;          // сколько клеток можно не узнать

    public static final class Result {
        public boolean ok;
        public String error = "";
        public float left, top, cell;
        /** Экранная ориентация: [строка сверху][столбец слева]; '.' пусто, '?' не узнана. */
        public final char[][] sq = new char[8][8];
        public final boolean[][] hl = new boolean[8][8];
        public float worstDist;
        public int unknown;
        public boolean usedHint;
    }

    public static final class Cell {
        public boolean piece;
        public float fgFrac;
        public float centerLum;
        public int[] bg = new int[3];
        public final float[] cov = new float[G * G];
    }

    private final int[] px;
    private final int w, h;

    public BoardReader(int[] px, int w, int h) {
        this.px = px;
        this.w = w;
        this.h = h;
    }

    private int get(int x, int y) {
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x >= w) x = w - 1;
        if (y >= h) y = h - 1;
        return px[y * w + x];
    }

    /** Пиксель похож на деталь фигуры (чёрную/белую/серую), а не на клетку, подсказку или стрелку. */
    private static boolean isFg(int rr, int gg, int bb, int bgLum, int bgChroma) {
        int mx = Math.max(rr, Math.max(gg, bb)), mn = Math.min(rr, Math.min(gg, bb));
        int chroma = mx - mn;
        if (chroma > 30) return false;
        int lum = (299 * rr + 587 * gg + 114 * bb) / 1000;
        int dl = Math.abs(lum - bgLum);
        if (dl > 48) return true;
        if (lum < 110 && bgLum - lum >= 25) return true;
        if (lum > 150 && bgChroma - chroma >= 14) return true;
        if (bgChroma - chroma >= 40) return true;   // серый пиксель на сильно цветной клетке
        return false;
    }

    public Cell analyzeCell(float left, float top, float cell, int r, int c) {
        float x0 = left + c * cell, y0 = top + r * cell;
        Cell out = new Cell();
        out.bg = BoardFinder.cellColor(px, w, h, x0, y0, cell);
        int bgLum = (299 * out.bg[0] + 587 * out.bg[1] + 114 * out.bg[2]) / 1000;
        int bgChroma = Math.max(out.bg[0], Math.max(out.bg[1], out.bg[2]))
                - Math.min(out.bg[0], Math.min(out.bg[1], out.bg[2]));

        final float crop0 = 0.06f, cropSize = 0.88f;
        float gs = cropSize * cell / G;
        for (int gy = 0; gy < G; gy++) {
            for (int gx = 0; gx < G; gx++) {
                int cnt = 0;
                for (int sy = 0; sy < 3; sy++) {
                    for (int sx = 0; sx < 3; sx++) {
                        float fx = x0 + crop0 * cell + (gx + (sx + 0.5f) / 3f) * gs;
                        float fy = y0 + crop0 * cell + (gy + (sy + 0.5f) / 3f) * gs;
                        int p = get((int) fx, (int) fy);
                        int rr = (p >> 16) & 255, g2 = (p >> 8) & 255, bb = p & 255;
                        if (isFg(rr, g2, bb, bgLum, bgChroma)) cnt++;
                    }
                }
                out.cov[gy * G + gx] = cnt / 9f;
            }
        }
        fillHoles(out.cov);

        int lo = (int) (G * 0.15f), hi = (int) (G * 0.85f);
        float sum = 0;
        for (int gy = lo; gy < hi; gy++) for (int gx = lo; gx < hi; gx++) sum += out.cov[gy * G + gx];
        out.fgFrac = sum / ((hi - lo) * (hi - lo));
        out.piece = out.fgFrac > EMPTY_THRESH;

        // яркость середины фигуры: медиана по 5x5 точкам
        int[] lums = new int[25];
        int n = 0;
        for (int iy = 0; iy < 5; iy++) {
            for (int ix = 0; ix < 5; ix++) {
                int p = get((int) (x0 + (0.40f + 0.05f * ix) * cell), (int) (y0 + (0.40f + 0.05f * iy) * cell));
                lums[n++] = (299 * ((p >> 16) & 255) + 587 * ((p >> 8) & 255) + 114 * (p & 255)) / 1000;
            }
        }
        java.util.Arrays.sort(lums);
        out.centerLum = lums[12];
        return out;
    }

    /** Если контур фигуры замкнут, всё, что внутри, тоже считаем фигурой (заливка могла слиться с клеткой). */
    static void fillHoles(float[] cov) {
        boolean[] outside = new boolean[G * G];
        int[] stack = new int[G * G];
        int sp = 0;
        for (int i = 0; i < G; i++) {
            int[] border = {i, (G - 1) * G + i, i * G, i * G + G - 1};
            for (int b : border) {
                if (cov[b] < 0.25f && !outside[b]) {
                    outside[b] = true;
                    stack[sp++] = b;
                }
            }
        }
        while (sp > 0) {
            int k = stack[--sp];
            int y = k / G, x = k % G;
            if (y > 0) sp = push(cov, outside, stack, sp, k - G);
            if (y < G - 1) sp = push(cov, outside, stack, sp, k + G);
            if (x > 0) sp = push(cov, outside, stack, sp, k - 1);
            if (x < G - 1) sp = push(cov, outside, stack, sp, k + 1);
        }
        for (int k = 0; k < G * G; k++) if (cov[k] < 0.25f && !outside[k]) cov[k] = 1f;
    }

    private static int push(float[] cov, boolean[] outside, int[] stack, int sp, int k) {
        if (!outside[k] && cov[k] < 0.25f) {
            outside[k] = true;
            stack[sp++] = k;
        }
        return sp;
    }

    // ------------------------------------------------------ шаблоны

    private static float[][] tpl;

    private static synchronized float[][] templates() {
        if (tpl == null) {
            String[] d = Templates.DATA;
            float[][] t = new float[d.length][G * G];
            for (int i = 0; i < d.length; i++) {
                String s = d[i];
                float[] raw = new float[G * G];
                for (int k = 0; k < G * G; k++) raw[k] = (s.charAt(k) - '0') / 9f;
                t[i] = blur(raw);
            }
            tpl = t;
        }
        return tpl;
    }

    /** Размытие 3x3: делает сравнение устойчивым к толщине контура фигуры. */
    static float[] blur(float[] a) {
        float[] o = new float[G * G];
        for (int y = 0; y < G; y++) {
            for (int x = 0; x < G; x++) {
                float s = 0;
                int n = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int yy = y + dy, xx = x + dx;
                        if (yy < 0 || yy >= G || xx < 0 || xx >= G) continue;
                        s += a[yy * G + xx];
                        n++;
                    }
                }
                o[y * G + x] = s / n;
            }
        }
        return o;
    }

    /** @return {индекс типа 0..5, расстояние до лучшего, расстояние до второго} среди шаблонов нужного цвета. */
    static float[] classify(float[] cov, boolean white) {
        float[][] t = templates();
        float[] bc = blur(cov);
        int best = -1;
        float bd = 1e9f, sd = 1e9f;
        for (int ty = 0; ty < 6; ty++) {
            float[] tp = t[(white ? 0 : 6) + ty];
            float s = 0;
            for (int k = 0; k < G * G; k++) s += Math.abs(bc[k] - tp[k]);
            s /= (G * G);
            if (s < bd) {
                sd = bd;
                bd = s;
                best = ty;
            } else if (s < sd) {
                sd = s;
            }
        }
        return new float[]{best, bd, sd};
    }

    /** Принимаем фигуру, если она близка к шаблону или заметно ближе к нему, чем к остальным типам. */
    static boolean accept(float[] m) {
        return m[1] <= MAX_DIST || (m[1] <= MAX_DIST_LOOSE && m[2] >= m[1] * MARGIN);
    }

    // ------------------------------------------------------ главный метод

    /**
     * @param hint        прежнее/ручное положение доски {left, top, cell} или null
     * @param forceHint   true: верить hint даже если проверка слабая (ручная калибровка)
     */
    public static Result read(int[] px, int w, int h, float[] hint, boolean forceHint) {
        Result res = new Result();
        BoardReader br = new BoardReader(px, w, h);

        float[] g = null;
        if (hint != null) {
            float[] rg = BoardFinder.refine(px, w, h, hint[0], hint[1], hint[2], 0.12f);
            rg = BoardFinder.refine(px, w, h, rg[0], rg[1], rg[2], 0.05f);
            int v = BoardFinder.verify(px, w, h, rg[0], rg[1], rg[2]);
            if (v >= BoardFinder.MIN_VERIFY - 6) {
                g = rg;
                res.usedHint = true;
            } else if (forceHint) {
                g = hint;
                res.usedHint = true;
            }
        }
        if (g == null) {
            float[] f = BoardFinder.find(px, w, h);
            if (f == null) {
                res.error = "Доска не найдена на экране";
                return res;
            }
            g = f;
        }
        res.left = g[0];
        res.top = g[1];
        res.cell = g[2];

        Cell[][] cells = new Cell[8][8];
        int[][] par = new int[2][];
        for (int p = 0; p < 2; p++) {
            int[] rs = new int[32], gs = new int[32], bs = new int[32];
            int n = 0;
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    if (((r + c) & 1) != p) continue;
                    int[] bg = BoardFinder.cellColor(px, w, h, res.left + c * res.cell, res.top + r * res.cell, res.cell);
                    rs[n] = bg[0]; gs[n] = bg[1]; bs[n] = bg[2];
                    n++;
                }
            }
            java.util.Arrays.sort(rs); java.util.Arrays.sort(gs); java.util.Arrays.sort(bs);
            par[p] = new int[]{rs[16], gs[16], bs[16]};
        }

        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                Cell cl = br.analyzeCell(res.left, res.top, res.cell, r, c);
                cells[r][c] = cl;
                int[] ref = par[(r + c) & 1];
                int dev = Math.abs(cl.bg[0] - ref[0]) + Math.abs(cl.bg[1] - ref[1]) + Math.abs(cl.bg[2] - ref[2]);
                res.hl[r][c] = dev > 60;
                if (!cl.piece) {
                    res.sq[r][c] = '.';
                    continue;
                }
                boolean white = cl.centerLum >= WHITE_LUM;
                float[] m = classify(cl.cov, white);
                if (!accept(m)) {
                    res.sq[r][c] = '?';
                    res.unknown++;
                    if (res.unknown > MAX_UNKNOWN) {
                        res.error = "Не узнаю фигуры (клетка " + (char) ('a' + c) + (8 - r) + ")";
                        return res;
                    }
                    continue;
                }
                if (m[1] > res.worstDist) res.worstDist = m[1];
                char ch = ORDER.charAt((int) m[0]);
                res.sq[r][c] = white ? ch : Character.toLowerCase(ch);
            }
        }
        res.ok = true;
        return res;
    }
}
