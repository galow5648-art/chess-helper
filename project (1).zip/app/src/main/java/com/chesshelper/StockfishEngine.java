package com.chesshelper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.concurrent.LinkedBlockingQueue;

/** Тонкая обёртка над UCI-движком (Stockfish) как над дочерним процессом. */
public final class StockfishEngine {

    public static final class Line {
        public String move = "";
        public int cp;
        public boolean mate;
        public int mateIn;
        public int depth;
    }

    public static final class Result {
        public String fen;
        public Line[] lines;
        public int depth;
    }

    public interface Callback {
        /** Промежуточный результат: подсказка уже есть, но расчёт ещё идёт. */
        void onProgress(Result r);

        void onResult(Result r);

        void onError(String msg);
    }

    private static final class Job {
        final String posCmd;
        final String fen;
        final int movetime;
        final int multiPv;
        final Callback cb;
        volatile boolean cancelled;

        Job(String posCmd, String fen, int movetime, int multiPv, Callback cb) {
            this.posCmd = posCmd;
            this.fen = fen;
            this.movetime = movetime;
            this.multiPv = multiPv;
            this.cb = cb;
        }
    }

    private final String path;
    private final int threads;
    private final int hashMb;
    private final Object lock = new Object();
    private final LinkedBlockingQueue<Job> queue = new LinkedBlockingQueue<Job>();
    private volatile Job current;
    private volatile boolean stopped;
    private Process proc;
    private BufferedWriter out;
    private BufferedReader in;
    private Thread worker;

    public StockfishEngine(String path, int threads, int hashMb) {
        this.path = path;
        this.threads = Math.max(1, threads);
        this.hashMb = hashMb;
    }

    public void start() {
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        }, "stockfish-worker");
        worker.setDaemon(true);
        worker.start();
    }

    /** posCmd - то, что идёт после слова position, например "fen <FEN> moves e2e4"; fen нужен для сверки результата. */
    public void analyze(String posCmd, String fen, int movetimeMs, int multiPv, Callback cb) {
        synchronized (lock) {
            queue.clear();
            Job old = current;
            if (old != null) {
                old.cancelled = true;
                send("stop");
            }
            queue.add(new Job(posCmd, fen, movetimeMs, multiPv, cb));
        }
    }

    public void cancel() {
        synchronized (lock) {
            queue.clear();
            Job old = current;
            if (old != null) {
                old.cancelled = true;
                send("stop");
            }
        }
    }

    public void stop() {
        stopped = true;
        cancel();
        send("quit");
        if (proc != null) proc.destroy();
        if (worker != null) worker.interrupt();
    }

    // ------------------------------------------------------------------

    private void send(String cmd) {
        try {
            BufferedWriter w = out;
            if (w == null) return;
            synchronized (w) {
                w.write(cmd);
                w.write("\n");
                w.flush();
            }
        } catch (IOException ignored) {
            // процесс умер - обнаружим в читающем цикле
        }
    }

    private void startProcess() throws IOException {
        ProcessBuilder pb = new ProcessBuilder(path);
        pb.redirectErrorStream(true);
        proc = pb.start();
        out = new BufferedWriter(new OutputStreamWriter(proc.getOutputStream()));
        in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
        send("uci");
        String line;
        while ((line = in.readLine()) != null) {
            if (line.startsWith("uciok")) break;
        }
        if (line == null) throw new IOException("Движок завершился при запуске");
        send("setoption name Threads value " + threads);
        send("setoption name Hash value " + hashMb);
        send("isready");
        while ((line = in.readLine()) != null) {
            if (line.startsWith("readyok")) break;
        }
        if (line == null) throw new IOException("Движок не ответил readyok");
    }

    private void loop() {
        while (!stopped) {
            Job j;
            try {
                j = queue.take();
            } catch (InterruptedException e) {
                return;
            }
            synchronized (lock) {
                if (j.cancelled) continue;
                current = j;
            }
            try {
                if (proc == null || !proc.isAlive()) startProcess();
                search(j);
            } catch (IOException e) {
                if (proc != null) proc.destroy();
                proc = null;
                out = null;
                if (!j.cancelled && !stopped) j.cb.onError("Движок: " + e.getMessage());
            } finally {
                current = null;
            }
        }
    }

    private void search(Job j) throws IOException {
        send("setoption name MultiPV value " + j.multiPv);
        send("position " + j.posCmd);
        send("go movetime " + j.movetime);
        Line[] lines = new Line[j.multiPv];
        int maxDepth = 0;
        long lastProgress = System.currentTimeMillis();
        String line;
        while ((line = in.readLine()) != null) {
            if (line.startsWith("info ")) {
                int d = parseInfo(line, lines);
                if (d > maxDepth) maxDepth = d;
                long now = System.currentTimeMillis();
                if (d > 0 && maxDepth >= 8 && now - lastProgress >= 300 && !j.cancelled && lines[0] != null) {
                    lastProgress = now;
                    j.cb.onProgress(snapshot(j, lines, maxDepth));
                }
            } else if (line.startsWith("bestmove")) {
                if (!j.cancelled) {
                    // гарантируем лучший ход даже если info не пришёл
                    String[] t = line.split("\\s+");
                    if (lines[0] == null && t.length > 1 && !t[1].equals("(none)")) {
                        Line l = new Line();
                        l.move = t[1];
                        lines[0] = l;
                    }
                    j.cb.onResult(snapshot(j, lines, maxDepth));
                }
                return;
            }
        }
        throw new IOException("Процесс движка завершился");
    }

    private static Result snapshot(Job j, Line[] lines, int depth) {
        int n = 0;
        for (Line l : lines) if (l != null && l.move.length() >= 4) n++;
        Line[] res = new Line[n];
        int k = 0;
        for (Line l : lines) if (l != null && l.move.length() >= 4) res[k++] = l;
        Result r = new Result();
        r.fen = j.fen;
        r.lines = res;
        r.depth = depth;
        return r;
    }

    /** Разбирает строку "info ..." и записывает в lines[multipv-1]. Возвращает глубину или 0. */
    static int parseInfo(String line, Line[] lines) {
        String[] t = line.split("\\s+");
        int depth = 0, pv = 1;
        Integer cp = null, mate = null;
        String move = null;
        for (int i = 1; i < t.length; i++) {
            String s = t[i];
            if (s.equals("depth") && i + 1 < t.length) {
                depth = safeInt(t[++i]);
            } else if (s.equals("multipv") && i + 1 < t.length) {
                pv = safeInt(t[++i]);
            } else if (s.equals("score") && i + 2 < t.length) {
                String kind = t[++i];
                int v = safeInt(t[++i]);
                if (kind.equals("cp")) cp = v;
                else if (kind.equals("mate")) mate = v;
            } else if (s.equals("pv") && i + 1 < t.length) {
                move = t[i + 1];
                break;
            }
        }
        if (move == null || (cp == null && mate == null)) return 0;
        if (pv < 1 || pv > lines.length) return 0;
        Line l = new Line();
        l.move = move;
        l.depth = depth;
        if (mate != null) {
            l.mate = true;
            l.mateIn = mate;
        } else {
            l.cp = cp;
        }
        lines[pv - 1] = l;
        return depth;
    }

    private static int safeInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
