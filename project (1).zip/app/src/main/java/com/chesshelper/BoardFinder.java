package com.chesshelper;

/**
 * Ищет шахматную доску на кадре БЕЗ привязки к цветам и теме: доска - это решётка 8x8,
 * где соседние клетки разных цветов. Ищем "углы" между четырьмя клетками (чередование знака
 * контраста), проверяем, что 7x7 внутренних углов выстраиваются в решётку, затем уточняем
 * положение по рёбрам в полном разрешении и проверяем 64 клетки.
 */
final class BoardFinder {
    private BoardFinder() {}

    static final int MIN_VERIFY = 46;   // из 64 клеток

    /** @return {left, top, cell, verifyScore} или null. */
    static float[] find(int[] px, int w, int h) {
        final int f = Math.max(2, Math.round(w / 270f));
        final int dw = w / f, dh = h / f;
        if (dw < 60 || dh < 60) return null;

        // уменьшенная копия по каналам + интегральные изображения
        int[] ir = new int[(dw + 1) * (dh + 1)];
        int[] ig = new int[(dw + 1) * (dh + 1)];
        int[] ib = new int[(dw + 1) * (dh + 1)];
        final int W1 = dw + 1;
        final int area = f * f;
        for (int y = 0; y < dh; y++) {
            int rowR = 0, rowG = 0, rowB = 0;
            for (int x = 0; x < dw; x++) {
                int sr = 0, sg = 0, sb = 0;
                for (int fy = 0; fy < f; fy++) {
                    int base = (y * f + fy) * w + x * f;
                    for (int fx = 0; fx < f; fx++) {
                        int p = px[base + fx];
                        sr += (p >> 16) & 255;
                        sg += (p >> 8) & 255;
                        sb += p & 255;
                    }
                }
                rowR += sr / area;
                rowG += sg / area;
                rowB += sb / area;
                ir[(y + 1) * W1 + x + 1] = ir[y * W1 + x + 1] + rowR;
                ig[(y + 1) * W1 + x + 1] = ig[y * W1 + x + 1] + rowG;
                ib[(y + 1) * W1 + x + 1] = ib[y * W1 + x + 1] + rowB;
            }
        }

        final int K = 10;
        float[] cS = new float[K];
        int[] cX = new int[K], cY = new int[K], cC = new int[K];
        int count = 0;

        int cmin = Math.max(8, (int) (dw * 0.5f / 8f));
        int cmax = dw / 8 + 1;
        for (int c = cmin; c <= cmax; c++) {
            int nx = (dw - 2 * c) / 2 + 1, ny = (dh - 2 * c) / 2 + 1;
            if (nx < 8 || ny < 8) continue;
            int[] mr = new int[nx * ny], mg = new int[nx * ny], mb = new int[nx * ny];
            for (int j = 0; j < ny; j++) {
                int y = c + 2 * j;
                for (int i = 0; i < nx; i++) {
                    int x = c + 2 * i;
                    int idx = j * nx + i;
                    mr[idx] = corner(ir, W1, x, y, c);
                    mg[idx] = corner(ig, W1, x, y, c);
                    mb[idx] = corner(ib, W1, x, y, c);
                }
            }
            int[] off = new int[7];
            for (int k = 0; k < 7; k++) off[k] = Math.round(k * c / 2f);
            int imax = nx - 1 - off[6], jmax = ny - 1 - off[6];
            for (int j = 0; j <= jmax; j++) {
                for (int i = 0; i <= imax; i++) {
                    int sr = 0, sg = 0, sb = 0;
                    for (int kj = 0; kj < 7; kj++) {
                        int rowIdx = (j + off[kj]) * nx + i;
                        for (int ki = 0; ki < 7; ki++) {
                            int idx = rowIdx + off[ki];
                            if (((ki + kj) & 1) == 0) {
                                sr += mr[idx]; sg += mg[idx]; sb += mb[idx];
                            } else {
                                sr -= mr[idx]; sg -= mg[idx]; sb -= mb[idx];
                            }
                        }
                    }
                    float s = (Math.abs(sr) + Math.abs(sg) + Math.abs(sb)) / (49f * c * c);
                    if (s < 14f) continue;
                    int x0 = c + 2 * i, y0 = c + 2 * j;
                    count = offer(cS, cX, cY, cC, count, K, s, x0, y0, c);
                }
            }
        }
        if (count == 0) return null;

        float bestScore = -1;
        float[] best = null;
        for (int i = 0; i < count; i++) {
            int c = cC[i];
            float left = (cX[i] - c) * (float) f, top = (cY[i] - c) * (float) f, cell = c * (float) f;
            float[] g = refine(px, w, h, left, top, cell, 0.22f);
            g = refine(px, w, h, g[0], g[1], g[2], 0.07f);
            int v = verify(px, w, h, g[0], g[1], g[2]);
            float sc = v + cS[i] * 0.001f;
            if (v >= MIN_VERIFY && sc > bestScore) {
                bestScore = sc;
                best = new float[]{g[0], g[1], g[2], v};
            }
        }
        return best;
    }

    private static int corner(int[] I, int W1, int x, int y, int c) {
        int tl = rect(I, W1, x - c, y - c, x, y);
        int tr = rect(I, W1, x, y - c, x + c, y);
        int bl = rect(I, W1, x - c, y, x, y + c);
        int br = rect(I, W1, x, y, x + c, y + c);
        return tl + br - tr - bl;
    }

    private static int rect(int[] I, int W1, int x0, int y0, int x1, int y1) {
        return I[y1 * W1 + x1] - I[y0 * W1 + x1] - I[y1 * W1 + x0] + I[y0 * W1 + x0];
    }

    /** Хранит лучшие K кандидатов с подавлением соседей. */
    private static int offer(float[] cS, int[] cX, int[] cY, int[] cC, int count, int K, float s, int x, int y, int c) {
        for (int i = 0; i < count; i++) {
            if (Math.abs(cX[i] - x) <= 0.8f * c && Math.abs(cY[i] - y) <= 0.8f * c && Math.abs(cC[i] - c) <= 3) {
                if (s > cS[i]) {
                    cS[i] = s; cX[i] = x; cY[i] = y; cC[i] = c;
                }
                return count;
            }
        }
        if (count < K) {
            cS[count] = s; cX[count] = x; cY[count] = y; cC[count] = c;
            return count + 1;
        }
        int worst = 0;
        for (int i = 1; i < count; i++) if (cS[i] < cS[worst]) worst = i;
        if (s > cS[worst]) {
            cS[worst] = s; cX[worst] = x; cY[worst] = y; cC[worst] = c;
        }
        return count;
    }

    // ------------------------------------------------------------ уточнение

    private static int lum(int p) {
        return ((p >> 16) & 255) + ((p >> 8) & 255) + (p & 255);
    }

    /** Подгоняет решётку по рёбрам между клетками в полном разрешении. */
    static float[] refine(int[] px, int w, int h, float left, float top, float cell, float winFrac) {
        float[] xs = fitLines(px, w, h, left, top, cell, true, winFrac);
        float[] ys = fitLines(px, w, h, left, top, cell, false, winFrac);
        if (xs == null || ys == null) return new float[]{left, top, cell};
        float c = (xs[1] + ys[1]) / 2f;
        if (Math.abs(xs[1] - ys[1]) > 0.04f * c) return new float[]{left, top, cell};
        // фиксируем общий размер клетки, пересчитываем левый/верхний край
        float l = xs[0], t = ys[0];
        return new float[]{l, t, c};
    }

    /** @return {начало, шаг} линии x_k = a + b*k по 7 внутренним границам или null. */
    private static float[] fitLines(int[] px, int w, int h, float left, float top, float cell, boolean vertical, float winFrac) {
        int win = Math.max(3, Math.round(cell * winFrac));
        float[] pos = new float[7];
        boolean[] okk = new boolean[7];
        int rows0, rows1;
        if (vertical) {
            rows0 = Math.round(top + cell * 0.3f);
            rows1 = Math.round(top + cell * 7.7f);
        } else {
            rows0 = Math.round(left + cell * 0.3f);
            rows1 = Math.round(left + cell * 7.7f);
        }
        int lim = vertical ? h : w;
        if (rows0 < 1) rows0 = 1;
        if (rows1 > lim - 2) rows1 = lim - 2;
        if (rows1 - rows0 < 20) return null;
        int n = 0;
        for (int k = 1; k <= 7; k++) {
            float expect = (vertical ? left : top) + k * cell;
            int c0 = Math.round(expect) - win, c1 = Math.round(expect) + win;
            int span = vertical ? w : h;
            if (c0 < 1 || c1 > span - 2) continue;
            long[] e = new long[c1 - c0 + 1];
            long bestE = -1;
            int bestI = -1;
            for (int ci = 0; ci < e.length; ci++) {
                int cc = c0 + ci;
                long sum = 0;
                for (int rr = rows0; rr < rows1; rr += 2) {
                    int a, b;
                    if (vertical) {
                        a = lum(px[rr * w + cc + 1]);
                        b = lum(px[rr * w + cc - 1]);
                    } else {
                        a = lum(px[(cc + 1) * w + rr]);
                        b = lum(px[(cc - 1) * w + rr]);
                    }
                    sum += Math.abs(a - b);
                }
                e[ci] = sum;
                if (sum > bestE) {
                    bestE = sum;
                    bestI = ci;
                }
            }
            float sub = 0;
            if (bestI > 0 && bestI < e.length - 1) {
                double d = e[bestI - 1] - 2.0 * e[bestI] + e[bestI + 1];
                if (d < 0) sub = (float) (0.5 * (e[bestI - 1] - e[bestI + 1]) / d);
                if (sub > 1f) sub = 1f;
                if (sub < -1f) sub = -1f;
            }
            pos[k - 1] = c0 + bestI + sub;
            okk[k - 1] = true;
            n++;
        }
        if (n < 5) return null;
        float[] fit = null;
        for (int iter = 0; iter < 3; iter++) {
            double sk = 0, sp = 0, skk = 0, skp = 0;
            int m = 0;
            for (int k = 1; k <= 7; k++) {
                if (!okk[k - 1]) continue;
                sk += k; sp += pos[k - 1]; skk += (double) k * k; skp += k * pos[k - 1];
                m++;
            }
            double den = m * skk - sk * sk;
            if (m < 4 || Math.abs(den) < 1e-6) return null;
            double b = (m * skp - sk * sp) / den;
            double a = (sp - b * sk) / m;
            fit = new float[]{(float) a, (float) b};
            // выбрасываем худший выброс
            double worst = 0;
            int wi = -1;
            for (int k = 1; k <= 7; k++) {
                if (!okk[k - 1]) continue;
                double r = Math.abs(pos[k - 1] - (a + b * k));
                if (r > worst) {
                    worst = r;
                    wi = k - 1;
                }
            }
            if (worst > 0.03 * cell && m > 4) okk[wi] = false;
            else break;
        }
        return fit;
    }

    // ------------------------------------------------------------ проверка

    /** Сколько клеток из 64 согласуются с двухцветным шахматным узором (0..64). */
    static int verify(int[] px, int w, int h, float left, float top, float cell) {
        if (left < -2 || top < -2 || left + 8 * cell > w + 2 || top + 8 * cell > h + 2 || cell < 12) return 0;
        int[][] col = new int[64][];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) col[r * 8 + c] = cellColor(px, w, h, left + c * cell, top + r * cell, cell);
        }
        int[][] par = new int[2][];
        for (int p = 0; p < 2; p++) {
            int[] rs = new int[32], gs = new int[32], bs = new int[32];
            int n = 0;
            for (int i = 0; i < 64; i++) {
                if ((((i >> 3) + (i & 7)) & 1) != p) continue;
                rs[n] = col[i][0]; gs[n] = col[i][1]; bs[n] = col[i][2];
                n++;
            }
            java.util.Arrays.sort(rs); java.util.Arrays.sort(gs); java.util.Arrays.sort(bs);
            par[p] = new int[]{rs[16], gs[16], bs[16]};
        }
        int contrast = Math.abs(par[0][0] - par[1][0]) + Math.abs(par[0][1] - par[1][1]) + Math.abs(par[0][2] - par[1][2]);
        if (contrast < 28) return 0;
        int ok = 0;
        for (int i = 0; i < 64; i++) {
            int[] ref = par[((i >> 3) + (i & 7)) & 1];
            int d = Math.abs(col[i][0] - ref[0]) + Math.abs(col[i][1] - ref[1]) + Math.abs(col[i][2] - ref[2]);
            if (d < 60) ok++;
        }
        return ok;
    }

    /** Цвет фона клетки: медиана по точкам у боковых сторон (фигура сюда не заходит). */
    static int[] cellColor(int[] px, int w, int h, float x0, float y0, float cell) {
        final float[] fx = {0.06f, 0.94f, 0.06f, 0.94f, 0.06f, 0.94f};
        final float[] fy = {0.35f, 0.35f, 0.50f, 0.50f, 0.65f, 0.65f};
        int[] rs = new int[6], gs = new int[6], bs = new int[6];
        for (int i = 0; i < 6; i++) {
            int x = (int) (x0 + fx[i] * cell), y = (int) (y0 + fy[i] * cell);
            if (x < 0) x = 0;
            if (y < 0) y = 0;
            if (x >= w) x = w - 1;
            if (y >= h) y = h - 1;
            int p = px[y * w + x];
            rs[i] = (p >> 16) & 255;
            gs[i] = (p >> 8) & 255;
            bs[i] = p & 255;
        }
        java.util.Arrays.sort(rs); java.util.Arrays.sort(gs); java.util.Arrays.sort(bs);
        return new int[]{(rs[2] + rs[3]) / 2, (gs[2] + gs[3]) / 2, (bs[2] + bs[3]) / 2};
    }
}
