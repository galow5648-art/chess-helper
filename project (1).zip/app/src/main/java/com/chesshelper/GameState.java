package com.chesshelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Следит за партией. Каждое чтение доски сопоставляется с отслеживаемой позицией:
 *  - позиция не изменилась -> ничего не делаем;
 *  - иначе ищем 1-3 легальных хода, дающих увиденную доску (так узнаём настоящие права на рокировку,
 *    взятие на проходе, счётчики, и копим историю ходов для движка);
 *  - не нашли (новая партия, сбой чтения) -> начинаем заново по эвристике.
 * Неузнанные клетки ('?') считаются подстановочными знаками.
 */
public final class GameState {

    public static final class Position {
        public boolean stable;          // доску видели два раза подряд одинаково
        public String fen;
        public String posCmd;           // "fen <FEN> moves ..." для движка
        public boolean whiteBottom, whiteToMove, userToMove;
        public float left, top, cell;
        public Chess.Pos pos;
        public List<Chess.Move> legal;
    }

    public String lastError = "";

    private boolean orientKnown;
    private boolean whiteBottom = true;
    private Chess.Pos cur;
    private String baseFen;
    private final ArrayList<String> moves = new ArrayList<String>();
    private String lastKey;

    public synchronized void flip() {
        whiteBottom = !whiteBottom;
        orientKnown = true;
        cur = null;
        lastKey = null;
    }

    public synchronized void reset() {
        orientKnown = false;
        cur = null;
        lastKey = null;
    }

    // ------------------------------------------------------------ основной метод

    public synchronized Position build(BoardReader.Result r) {
        // экранные клетки -> по ориентации
        boolean guess = guessWhiteBottom(r.sq);
        char[] bTry = toChess(r.sq, guess);
        if (new String(bTry).equals(START)) {
            whiteBottom = guess;
            orientKnown = true;
        } else if (!orientKnown) {
            whiteBottom = guess;
            orientKnown = true;
        }
        char[] b = toChess(r.sq, whiteBottom);
        boolean[] h = toChessBool(r.hl, whiteBottom);

        String key = new String(b);
        boolean stable = key.equals(lastKey);
        lastKey = key;
        Position out = new Position();
        out.left = r.left;
        out.top = r.top;
        out.cell = r.cell;
        out.stable = stable;
        if (!stable) {
            out.whiteBottom = whiteBottom;
            return out;   // увидим ещё раз - тогда поверим
        }

        // слежение: пробуем текущую ориентацию, затем перевёрнутую (доску могли перевернуть в приложении)
        Chess.Pos found = null;
        if (cur != null) {
            for (int o = 0; o < 2 && found == null; o++) {
                boolean wbo = (o == 0) == whiteBottom;
                char[] bo = o == 0 ? b : toChess(r.sq, wbo);
                boolean[] ho = o == 0 ? h : toChessBool(r.hl, wbo);
                if (matches(cur.b, bo)) {
                    found = cur;                       // без изменений
                } else {
                    ArrayList<Chess.Move> path = new ArrayList<Chess.Move>();
                    Chess.Pos f = findPath(cur, bo, ho, path);
                    if (f != null) {
                        found = f;
                        for (Chess.Move m : path) moves.add(m.uci());
                        if (moves.size() > 300) {
                            baseFen = Chess.fen(f);
                            moves.clear();
                        }
                    }
                }
                if (found != null && o == 1) whiteBottom = wbo;
            }
        }
        if (found == null) {
            found = initFrom(b, h);
            if (found == null) return null;   // lastError заполнен
            baseFen = Chess.fen(found);
            moves.clear();
        }
        cur = found;
        out.whiteBottom = whiteBottom;

        out.pos = cur;
        out.fen = Chess.fen(cur);
        out.whiteToMove = cur.white;
        out.userToMove = (cur.white == whiteBottom);
        out.legal = Chess.legal(cur);
        StringBuilder sb = new StringBuilder("fen ").append(baseFen);
        if (!moves.isEmpty()) {
            sb.append(" moves");
            for (String m : moves) sb.append(' ').append(m);
        }
        out.posCmd = sb.toString();
        lastError = "";
        return out;
    }

    // ------------------------------------------------------------ сопоставление

    private static boolean matches(char[] pos, char[] reading) {
        for (int i = 0; i < 64; i++) {
            char c = reading[i];
            if (c != '?' && c != pos[i]) return false;
        }
        return true;
    }

    private static final class Node {
        final Chess.Pos pos;
        final ArrayList<Chess.Move> path;

        Node(Chess.Pos pos, ArrayList<Chess.Move> path) {
            this.pos = pos;
            this.path = path;
        }
    }

    /** Ищет 1-3 легальных хода от start, после которых доска совпадает с чтением. */
    private static Chess.Pos findPath(Chess.Pos start, char[] target, boolean[] hl, ArrayList<Chess.Move> outPath) {
        ArrayList<Node> frontier = new ArrayList<Node>();
        frontier.add(new Node(start, new ArrayList<Chess.Move>()));
        for (int depth = 1; depth <= 3; depth++) {
            ArrayList<Node> next = new ArrayList<Node>();
            ArrayList<Node> hits = new ArrayList<Node>();
            for (Node n : frontier) {
                for (Chess.Move m : Chess.legal(n.pos)) {
                    Chess.Pos q = Chess.apply(n.pos, m);
                    ArrayList<Chess.Move> p2 = new ArrayList<Chess.Move>(n.path);
                    p2.add(m);
                    Node nn = new Node(q, p2);
                    if (matches(q.b, target)) hits.add(nn);
                    else if (depth < 3) next.add(nn);
                }
            }
            if (!hits.isEmpty()) {
                Node best = hits.get(0);
                if (hits.size() > 1) {
                    int bestScore = -1;
                    for (Node n : hits) {
                        Chess.Move last = n.path.get(n.path.size() - 1);
                        int sc = (hl[last.from] ? 1 : 0) + (hl[last.to] ? 1 : 0);
                        if (sc > bestScore) {
                            bestScore = sc;
                            best = n;
                        }
                    }
                }
                outPath.addAll(best.path);
                return best.pos;
            }
            frontier = next;
        }
        return null;
    }

    // ------------------------------------------------------------ начальная инициализация

    static final String START = "RNBQKBNRPPPPPPPP................................pppppppprnbqkbnr";

    private Chess.Pos initFrom(char[] b, boolean[] h) {
        for (int i = 0; i < 64; i++) {
            if (b[i] == '?') {
                lastError = "Не узнаю фигуру (клетка " + Chess.name(i) + ")";
                return null;
            }
        }
        int wk = 0, bk = 0;
        for (int i = 0; i < 64; i++) {
            if (b[i] == 'K') wk++;
            if (b[i] == 'k') bk++;
            if ((b[i] == 'P' || b[i] == 'p') && ((i >> 3) == 0 || (i >> 3) == 7)) {
                lastError = "Пешка на крайней горизонтали - не доверяю чтению";
                return null;
            }
        }
        if (wk != 1 || bk != 1) {
            lastError = "Не вижу обоих королей (" + wk + "/" + bk + ")";
            return null;
        }
        Chess.Pos p = new Chess.Pos();
        System.arraycopy(b, 0, p.b, 0, 64);
        boolean isStart = new String(b).equals(START);
        p.wk = b[4] == 'K' && b[7] == 'R';
        p.wq = b[4] == 'K' && b[0] == 'R';
        p.bk = b[60] == 'k' && b[63] == 'r';
        p.bq = b[60] == 'k' && b[56] == 'r';

        // чей ход: по цвету фигуры на подсвеченной клетке (сходил тот, кто стоит на ней)
        int hlCount = 0;
        boolean sawW = false, sawB = false;
        int h0 = -1, h1 = -1;
        for (int i = 0; i < 64; i++) {
            if (!h[i]) continue;
            hlCount++;
            if (h0 < 0) h0 = i; else if (h1 < 0) h1 = i;
            if (b[i] != '.') {
                if (Chess.isWhite(b[i])) sawW = true; else sawB = true;
            }
        }
        Boolean whiteToMove = null;
        if (hlCount >= 1 && hlCount <= 2 && (sawW ^ sawB)) whiteToMove = !sawW;
        if (whiteToMove == null) whiteToMove = isStart ? Boolean.TRUE : Boolean.valueOf(whiteBottom);
        p.white = whiteToMove;

        // взятие на проходе: двойной ход пешки по подсветке
        if (hlCount == 2 && (h0 & 7) == (h1 & 7) && Math.abs((h0 >> 3) - (h1 >> 3)) == 2) {
            int dest = b[h0] != '.' ? h0 : h1;
            int orig = dest == h0 ? h1 : h0;
            if ((b[dest] == 'P' && (orig >> 3) == 1) || (b[dest] == 'p' && (orig >> 3) == 6)) p.ep = (orig + dest) / 2;
        }

        if (Chess.inCheck(p, !p.white)) {
            lastError = "Позиция выглядит невозможной (шах стороне без хода)";
            return null;
        }
        return p;
    }

    // ------------------------------------------------------------ ориентация и преобразования

    private static boolean guessWhiteBottom(char[][] sq) {
        double wSum = 0, bSum = 0;
        int wN = 0, bN = 0;
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                char ch = sq[row][col];
                if (ch == '.' || ch == '?') continue;
                if (Chess.isWhite(ch)) { wSum += row; wN++; } else { bSum += row; bN++; }
            }
        }
        if (wN == 0 || bN == 0) return true;
        return (wSum / wN) > (bSum / bN);
    }

    /** Экран [строка сверху][столбец] -> индекс rank*8+file. */
    static char[] toChess(char[][] sq, boolean whiteBottom) {
        char[] b = new char[64];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                int rk = whiteBottom ? 7 - row : row;
                int f = whiteBottom ? col : 7 - col;
                b[rk * 8 + f] = sq[row][col];
            }
        }
        return b;
    }

    static boolean[] toChessBool(boolean[][] sq, boolean whiteBottom) {
        boolean[] b = new boolean[64];
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                int rk = whiteBottom ? 7 - row : row;
                int f = whiteBottom ? col : 7 - col;
                b[rk * 8 + f] = sq[row][col];
            }
        }
        return b;
    }
}
