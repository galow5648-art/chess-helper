package com.chesshelper;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Прозрачный экран-оверлей, на котором рисуются стрелки ходов. Касания пропускает. */
public final class ArrowView extends View {

    public static final class Arrow {
        public final float x1, y1, x2, y2;
        public final int color;
        public final float width;   // толщина в долях клетки

        public Arrow(float x1, float y1, float x2, float y2, int color, float width) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.color = color;
            this.width = width;
        }
    }

    private Arrow[] arrows = new Arrow[0];
    private float cell = 100f;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final int[] loc = new int[2];

    public ArrowView(Context context) {
        super(context);
        paint.setStyle(Paint.Style.FILL);
    }

    public void setArrows(Arrow[] a, float cellSize) {
        this.arrows = a;
        this.cell = cellSize;
        postInvalidate();
    }

    public void clear() {
        setArrows(new Arrow[0], cell);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // координаты стрелок - экранные, а окно может начинаться не с (0,0)
        getLocationOnScreen(loc);
        canvas.translate(-loc[0], -loc[1]);
        // сначала слабые стрелки, потом лучшая поверх
        for (int i = arrows.length - 1; i >= 0; i--) drawArrow(canvas, arrows[i]);
    }

    private void drawArrow(Canvas canvas, Arrow a) {
        float dx = a.x2 - a.x1, dy = a.y2 - a.y1;
        float len = (float) Math.hypot(dx, dy);
        if (len < 1f) return;
        float ux = dx / len, uy = dy / len;       // направление
        float px = -uy, py = ux;                  // перпендикуляр
        float sw = cell * a.width / 2f;           // половина толщины стебля
        float hw = sw * 2.3f;                     // половина ширины наконечника
        float head = cell * 0.42f;

        float sx = a.x1 + ux * cell * 0.22f, sy = a.y1 + uy * cell * 0.22f;   // начало чуть в стороне от центра
        float tx = a.x2 - ux * cell * 0.08f, ty = a.y2 - uy * cell * 0.08f;   // остриё
        float bx = tx - ux * head, by = ty - uy * head;                         // основание наконечника

        path.reset();
        path.moveTo(sx + px * sw, sy + py * sw);
        path.lineTo(bx + px * sw, by + py * sw);
        path.lineTo(bx + px * hw, by + py * hw);
        path.lineTo(tx, ty);
        path.lineTo(bx - px * hw, by - py * hw);
        path.lineTo(bx - px * sw, by - py * sw);
        path.lineTo(sx - px * sw, sy - py * sw);
        path.close();
        paint.setColor(a.color);
        canvas.drawPath(path, paint);
    }
}
