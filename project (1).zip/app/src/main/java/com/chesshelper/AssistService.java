package com.chesshelper;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.List;
import java.util.Locale;

/**
 * Основной сервис: захватывает экран, находит и читает доску, следит за партией,
 * спрашивает Stockfish и рисует стрелки. Потоки: main (вью), bg (захват и распознавание), поток движка.
 */
public class AssistService extends Service {

    public static final String ACTION_STOP = "com.chesshelper.STOP";
    private static final String CHANNEL = "assist";
    private static final int ANALYSIS_MS = 2500;

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread bgThread;
    private Handler bg;

    private WindowManager wm;
    private ArrowView arrowView;
    private LinearLayout panel;
    private TextView statusTv;
    private WindowManager.LayoutParams panelLp;
    private CalibView calibView;
    private boolean panelMoved;
    private float panelTopShown = -1;
    private int panelHeight;

    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private ImageReader reader;
    private VirtualDisplay display;
    private Image held;            // только поток bg
    private int[] pxBuf;           // только поток bg
    private long lastHash;         // только поток bg

    private StockfishEngine engine;
    private final GameState state = new GameState();

    private volatile boolean running;
    private volatile boolean started;
    private volatile boolean dirty = true;
    private volatile boolean analyzing;
    private volatile boolean arrowShown;
    private volatile boolean calibrating;
    private volatile long ignoreUntil;
    private volatile String committedFen;
    private volatile GameState.Position committedPos;
    private volatile float[] geom;          // найденная доска {left, top, cell}
    private volatile float[] manualGeom;    // ручная калибровка
    private StockfishEngine.Result lastResult;   // только main
    private long lastAnalysis;
    private int failCount;

    private int screenW, screenH;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ============================================================ запуск

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        started = true;

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Помощник", NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, AssistService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Шахматный помощник работает")
                .setContentText("Нажми, чтобы остановить")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);

        try {
            int code = intent == null ? 0 : intent.getIntExtra("code", 0);
            Intent data = intent == null ? null : (Intent) intent.getParcelableExtra("data");
            if (data == null) throw new IllegalStateException("нет данных разрешения на запись экрана");

            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            DisplayMetrics dm = new DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;

            bgThread = new HandlerThread("capture");
            bgThread.start();
            bg = new Handler(bgThread.getLooper());

            setupOverlay();

            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            projectionCallback = new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopSelf();
                }
            };
            projection.registerCallback(projectionCallback, main);

            reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 4);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    onFrame(r);
                }
            }, bg);
            display = projection.createVirtualDisplay("chess-helper", screenW, screenH, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);

            setupEngine();

            running = true;
            lastAnalysis = SystemClock.elapsedRealtime();
            bg.post(tick);
        } catch (Throwable t) {
            Toast.makeText(this, "Не удалось запустить: " + t, Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void setupEngine() {
        File sf = new File(getApplicationInfo().nativeLibraryDir, "libstockfish.so");
        if (!sf.exists()) {
            setStatus("Stockfish не найден в приложении");
            return;
        }
        int threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 2));
        engine = new StockfishEngine(sf.getAbsolutePath(), threads, 96);
        engine.start();
    }

    // ============================================================ оверлей

    private void setupOverlay() {
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        arrowView = new ArrowView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(arrowView, lp);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setPadding(dp(10), dp(6), dp(4), dp(6));
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(0xE6202020);
        bgd.setCornerRadius(dp(10));
        panel.setBackground(bgd);

        statusTv = new TextView(this);
        statusTv.setTextSize(13);
        statusTv.setTextColor(0xFFFFFFFF);
        statusTv.setMaxLines(4);
        statusTv.setText("Открой партию в Chess.com");
        panel.addView(statusTv, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // панель можно перетаскивать за текст
        statusTv.setOnTouchListener(new View.OnTouchListener() {
            private float sx, sy;
            private int px, py;

            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                int a = ev.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) {
                    sx = ev.getRawX();
                    sy = ev.getRawY();
                    px = panelLp.x;
                    py = panelLp.y;
                    return true;
                } else if (a == MotionEvent.ACTION_MOVE) {
                    panelLp.x = px + (int) (ev.getRawX() - sx);
                    panelLp.y = py + (int) (ev.getRawY() - sy);
                    panelMoved = true;
                    try {
                        wm.updateViewLayout(panel, panelLp);
                    } catch (Throwable ignored) {
                        // окно снято
                    }
                    return true;
                }
                return true;
            }
        });

        panel.addView(makeButton("⇅", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                state.flip();
                committedFen = null;
                lastResult = null;
                dirty = true;
                clearArrows();
                setStatus("Перевернул ориентацию, читаю…");
            }
        }));
        panel.addView(makeButton("▣", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startCalibration();
            }
        }));
        panel.addView(makeButton("✕", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        }));

        panelHeight = dp(84);
        int panelW = (int) (screenW * 0.78f);
        panelLp = new WindowManager.LayoutParams(
                panelW,
                panelHeight,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = screenW - panelW - dp(6);
        panelLp.y = (int) (screenH * 0.18f);
        panelLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(panel, panelLp);
    }

    private TextView makeButton(String text, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(20);
        b.setTextColor(0xFFB0BEC5);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(9), dp(4), dp(9), dp(4));
        b.setOnClickListener(l);
        return b;
    }

    /** Ставит панель над доской (или под ней, если сверху нет места), пока её не двигали руками. main. */
    private void positionPanel(GameState.Position p) {
        if (panel == null || panelMoved) return;
        float boardBottom = p.top + 8 * p.cell;
        float y;
        if (p.top > panelHeight + dp(10)) y = p.top - panelHeight - dp(6);
        else if (boardBottom + panelHeight + dp(10) < screenH) y = boardBottom + dp(6);
        else return;
        if (Math.abs(y - panelTopShown) < 2f) return;
        panelTopShown = y;
        panelLp.y = (int) y;
        try {
            wm.updateViewLayout(panel, panelLp);
        } catch (Throwable ignored) {
            // окно уже снято
        }
    }

    private void setStatus(final String text) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (statusTv != null) statusTv.setText(text);
            }
        });
    }

    private void clearArrows() {
        arrowShown = false;
        ignoreUntil = SystemClock.elapsedRealtime() + 800;
        main.post(new Runnable() {
            @Override
            public void run() {
                if (arrowView != null) arrowView.clear();
            }
        });
    }

    // ============================================================ калибровка

    private void startCalibration() {
        if (calibView != null) return;
        calibrating = true;
        clearArrows();
        float[] g = manualGeom != null ? manualGeom : geom;
        float left, top, side;
        if (g != null) {
            left = g[0];
            top = g[1];
            side = g[2] * 8f;
        } else {
            side = screenW * 0.94f;
            left = (screenW - side) / 2f;
            top = (screenH - side) / 2f;
        }
        calibView = new CalibView(this, left, top, side, getResources().getDisplayMetrics().density,
                new CalibView.Listener() {
                    @Override
                    public void onDone(float l, float t, float s, boolean auto) {
                        finishCalibration(l, t, s, auto);
                    }
                });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(calibView, lp);
    }

    private void finishCalibration(float l, float t, float s, boolean auto) {
        try {
            if (calibView != null) wm.removeView(calibView);
        } catch (Throwable ignored) {
            // не важно
        }
        calibView = null;
        if (auto) {
            manualGeom = null;
            geom = null;
            setStatus("Автоопределение доски включено");
        } else {
            manualGeom = new float[]{l, t, s / 8f};
            geom = manualGeom;
            setStatus("Рамка сохранена, читаю доску…");
        }
        state.reset();
        committedFen = null;
        lastResult = null;
        failCount = 0;
        calibrating = false;
        dirty = true;
    }

    // ============================================================ захват

    private void onFrame(ImageReader r) {
        Image img;
        try {
            img = r.acquireLatestImage();
        } catch (Throwable t) {
            return;
        }
        if (img == null) return;
        if (held != null) {
            try {
                held.close();
            } catch (Throwable ignored) {
                // уже закрыт
            }
        }
        held = img;
        float[] g = geom;
        if (g == null) return;
        long hsh;
        try {
            hsh = sparseHash(img, g);
        } catch (Throwable t) {
            return;
        }
        // "dirty" только когда изменилась сама доска; свои стрелки и панель в расчёт не идут
        if (hsh != lastHash) {
            lastHash = hsh;
            if (SystemClock.elapsedRealtime() >= ignoreUntil && !calibrating) dirty = true;
        }
    }

    /** Дешёвая "подпись" области доски: 32x32 точки. */
    private static long sparseHash(Image img, float[] g) {
        Image.Plane pl = img.getPlanes()[0];
        ByteBuffer bb = pl.getBuffer();
        int rs = pl.getRowStride();
        int w = img.getWidth(), h = img.getHeight();
        long hash = 1125899906842597L;
        float step = g[2] * 8f / 32f;
        for (int j = 0; j < 32; j++) {
            int y = (int) (g[1] + (j + 0.5f) * step);
            if (y < 0 || y >= h) continue;
            for (int i = 0; i < 32; i++) {
                int x = (int) (g[0] + (i + 0.5f) * step);
                if (x < 0 || x >= w) continue;
                hash = hash * 31 + bb.getInt(y * rs + x * 4);
            }
        }
        return hash;
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long now = SystemClock.elapsedRealtime();
            if (!calibrating) {
                // страховка: если стрелки нет, изредка перечитываем экран и без изменений
                if (!arrowShown && now - lastAnalysis > 3000) dirty = true;
                if (dirty && !analyzing) {
                    dirty = false;
                    analyzing = true;
                    lastAnalysis = now;
                    beginAnalysis();
                }
            }
            bg.postDelayed(this, 300);
        }
    };

    private void beginAnalysis() {
        if (arrowShown) {
            // позиция, возможно, изменилась: убираем стрелку, чтобы она не попала в кадр
            clearArrows();
            bg.postDelayed(new Runnable() {
                @Override
                public void run() {
                    captureAndRead();
                }
            }, 170);
        } else {
            captureAndRead();
        }
    }

    private void captureAndRead() {
        int[] px = null;
        int w = 0, h = 0;
        try {
            Image img = held;
            if (img != null) {
                w = img.getWidth();
                h = img.getHeight();
                px = toArgb(img, w, h);
            }
        } catch (Throwable t) {
            px = null;
        }
        try {
            if (px == null) {
                fail("Жду картинку с экрана…", false);
                return;
            }
            float[] man = manualGeom;
            float[] hint = man != null ? man : geom;
            BoardReader.Result r = BoardReader.read(px, w, h, hint, man != null);
            if (r.cell > 0) geom = new float[]{r.left, r.top, r.cell};
            handleReading(r);
        } catch (Throwable t) {
            fail("Ошибка чтения: " + t, false);
        } finally {
            analyzing = false;
        }
    }

    private int[] toArgb(Image img, int w, int h) {
        Image.Plane plane = img.getPlanes()[0];
        ByteBuffer bb = plane.getBuffer();
        int strideInts = plane.getRowStride() / 4;
        IntBuffer ib = bb.order(ByteOrder.nativeOrder()).asIntBuffer();
        if (pxBuf == null || pxBuf.length != w * h) pxBuf = new int[w * h];
        int[] out = pxBuf;
        for (int y = 0; y < h; y++) {
            ib.position(y * strideInts);
            ib.get(out, y * w, w);
        }
        for (int i = 0; i < out.length; i++) {
            int p = out[i];   // байты R,G,B,A -> int 0xAABBGGRR
            out[i] = 0xFF000000 | ((p & 0xFF) << 16) | (p & 0xFF00) | ((p >> 16) & 0xFF);
        }
        return out;
    }

    // ============================================================ логика

    private void fail(String message, boolean boardLost) {
        committedFen = null;
        committedPos = null;
        if (engine != null) engine.cancel();
        clearArrows();
        failCount++;
        if (boardLost) geom = null;
        String msg = message;
        if (boardLost && failCount >= 4 && manualGeom == null) msg = message + ". Нажми ▣ и укажи доску вручную";
        setStatus(msg);
        // не долбим процессор, пока доски нет на экране
        long delay = Math.min(3000, 700 + 400L * failCount);
        bg.postDelayed(new Runnable() {
            @Override
            public void run() {
                dirty = true;
            }
        }, delay);
    }

    private void handleReading(BoardReader.Result r) {
        if (!r.ok) {
            fail(r.error, r.cell <= 0);
            return;
        }
        final GameState.Position pos = state.build(r);
        if (pos == null) {
            fail(state.lastError, false);
            return;
        }
        failCount = 0;
        main.post(new Runnable() {
            @Override
            public void run() {
                positionPanel(pos);
            }
        });
        if (!pos.stable) {
            // доска изменилась: позицию надо увидеть два раза подряд, так отсеиваются анимации и перетаскивание
            if (engine != null) engine.cancel();
            committedFen = null;   // расчёт прерван: после стабилизации считаем заново
            clearArrows();
            setStatus("Читаю доску…");
            dirty = true;
            return;
        }
        if (pos.fen.equals(committedFen)) {
            // позиция не изменилась (стрелку убирали только на время чтения) - вернём её
            if (pos.userToMove) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        if (lastResult != null) showResult(lastResult, false);
                    }
                });
            }
            return;
        }
        committedFen = pos.fen;
        committedPos = pos;
        main.post(new Runnable() {
            @Override
            public void run() {
                lastResult = null;
            }
        });

        if (!pos.userToMove) {
            if (engine != null) engine.cancel();
            clearArrows();
            setStatus("Ход соперника…");
            return;
        }
        if (pos.legal.isEmpty()) {
            clearArrows();
            setStatus(Chess.inCheck(pos.pos, pos.pos.white) ? "Мат. Партия окончена" : "Пат. Партия окончена");
            return;
        }
        if (pos.legal.size() == 1) {
            StockfishEngine.Line l = new StockfishEngine.Line();
            l.move = pos.legal.get(0).uci();
            StockfishEngine.Result res = new StockfishEngine.Result();
            res.fen = pos.fen;
            res.lines = new StockfishEngine.Line[]{l};
            res.depth = 0;
            final StockfishEngine.Result fr = res;
            main.post(new Runnable() {
                @Override
                public void run() {
                    showResult(fr, true);
                }
            });
            return;
        }
        if (engine == null) {
            setStatus("Позиция прочитана, но движка нет");
            return;
        }
        setStatus("Думаю…");
        int ms = pos.legal.size() <= 3 ? 800 : ANALYSIS_MS;
        engine.analyze(pos.posCmd, pos.fen, ms, 3, new StockfishEngine.Callback() {
            @Override
            public void onProgress(final StockfishEngine.Result res) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        showResult(res, false);
                    }
                });
            }

            @Override
            public void onResult(final StockfishEngine.Result res) {
                main.post(new Runnable() {
                    @Override
                    public void run() {
                        showResult(res, true);
                    }
                });
            }

            @Override
            public void onError(String msg) {
                setStatus(msg);
            }
        });
    }

    /** main */
    private void showResult(StockfishEngine.Result res, boolean fin) {
        GameState.Position p = committedPos;
        if (!running || p == null || res == null || !res.fen.equals(committedFen) || res.lines.length == 0) return;
        lastResult = res;

        final int[] colors = {0xE62979FF, 0x99FF9800, 0x66FF9800};
        final float[] widths = {0.20f, 0.12f, 0.10f};
        ArrowView.Arrow[] arrows = new ArrowView.Arrow[res.lines.length];
        String[] san = new String[res.lines.length];
        List<Chess.Move> legal = p.legal;
        for (int i = 0; i < res.lines.length; i++) {
            String mv = res.lines[i].move;
            float[] a = center(p, mv.substring(0, 2));
            float[] b = center(p, mv.substring(2, 4));
            arrows[i] = new ArrowView.Arrow(a[0], a[1], b[0], b[1], colors[Math.min(i, 2)], widths[Math.min(i, 2)]);
            san[i] = mv;
            for (Chess.Move m : legal) {
                if (m.uci().equals(mv)) {
                    san[i] = Chess.san(p.pos, m, legal);
                    break;
                }
            }
        }

        StringBuilder sb = new StringBuilder();
        StockfishEngine.Line best = res.lines[0];
        sb.append("▶ ").append(san[0]).append("   (").append(fmtMove(best.move)).append(")");
        if (res.depth == 0) {
            sb.append("\nединственный ход");
        } else {
            sb.append('\n').append(fmtScore(best)).append(" · шанс ").append(winPct(best)).append("% · гл.")
                    .append(res.depth).append(fin ? "" : "…");
        }
        if (res.lines.length > 1) {
            sb.append('\n');
            for (int i = 1; i < res.lines.length; i++) {
                if (i > 1) sb.append("   ");
                sb.append(i + 1).append(") ").append(san[i]).append(' ').append(fmtScore(res.lines[i]));
            }
        }
        ignoreUntil = SystemClock.elapsedRealtime() + 800;
        arrowShown = true;
        arrowView.setArrows(arrows, p.cell);
        statusTv.setText(sb.toString());
    }

    private static float[] center(GameState.Position p, String sq) {
        int f = sq.charAt(0) - 'a';
        int rk = sq.charAt(1) - '1';
        int col = p.whiteBottom ? f : 7 - f;
        int row = p.whiteBottom ? 7 - rk : rk;
        return new float[]{p.left + (col + 0.5f) * p.cell, p.top + (row + 0.5f) * p.cell};
    }

    private static String fmtMove(String m) {
        String s = m.substring(0, 2) + "→" + m.substring(2, 4);
        if (m.length() >= 5) s += "=" + Character.toUpperCase(m.charAt(4));
        return s;
    }

    private static String fmtScore(StockfishEngine.Line l) {
        if (l.mate) return l.mateIn > 0 ? "мат в " + l.mateIn : "мат против " + (-l.mateIn);
        return String.format(Locale.US, "%+.2f", l.cp / 100f);
    }

    private static int winPct(StockfishEngine.Line l) {
        if (l.mate) return l.mateIn > 0 ? 100 : 0;
        return (int) Math.round(100.0 / (1.0 + Math.pow(10.0, -l.cp / 400.0)));
    }

    // ============================================================ остановка

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (engine != null) engine.stop();
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (calibView != null) wm.removeView(calibView);
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (arrowView != null) wm.removeView(arrowView);
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (panel != null) wm.removeView(panel);
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (display != null) display.release();
        } catch (Throwable ignored) {
            // не важно
        }
        try {
            if (projection != null) {
                if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
                projection.stop();
            }
        } catch (Throwable ignored) {
            // не важно
        }
        if (bg != null) {
            bg.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (held != null) held.close();
                        if (reader != null) reader.close();
                    } catch (Throwable ignored) {
                        // не важно
                    }
                    if (bgThread != null) bgThread.quitSafely();
                }
            });
        }
        super.onDestroy();
    }
}
